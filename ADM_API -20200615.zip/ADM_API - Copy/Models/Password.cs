﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public class Password
    {
        public string Pass { get; set; }
    }
}
