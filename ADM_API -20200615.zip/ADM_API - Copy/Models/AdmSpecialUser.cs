﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public class AdmSpecialUser : Audit
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required]
        public String UserID { get; set; }          //ok
        public String Username { get; set; }
        public String Password { get; set; }
        public String FullName { get; set; }
        public String Role { get; set; }
        public String Status { get; set; }
        public String UserType { get; set; }

        public String GroupUserID { get; set; }
        public AdmGroupUser AdmGroupUsers { get; set; }
    }
}
