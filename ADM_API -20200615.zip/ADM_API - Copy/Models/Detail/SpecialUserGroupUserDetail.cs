﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class SpecialUserGroupUserDetail
    {
        public String UserID { get; set; }          
        public String Username { get; set; }
        public String Password { get; set; }
        public String FullName { get; set; }
        public String Role { get; set; }
        public String Status { get; set; }
        public String UserType { get; set; }

        public String GroupUserID { get; set; }
        public String GroupUsername { get; set; }
        public String GroupDescription { get; set; }


    }
}
