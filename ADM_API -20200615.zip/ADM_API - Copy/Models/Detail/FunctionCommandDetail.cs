﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class FunctionCommandDetail
    {
        public string FunctionID { get; set; }
        public string FunctionName { get; set; }      
        public string ProjectID { get; set; }

        public List<string> CommandIDs { get; set; }
        //public List<AdmCommand> AdmCommands { get; set; }
    }
}
