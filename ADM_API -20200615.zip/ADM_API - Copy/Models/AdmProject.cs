﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public class AdmProject : Audit 
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public String ProjectID { get; set; }       //ok

        [Required]
        public String ProjectName { get; set; }
        public String Description { get; set; }
        public int Idx { get; set; }//pay attention
        public String Status { get; set; }

        public ICollection<AdmFunction> AdmFunctions { get; set; }
        public ICollection<AdmGroupUser> AdmGroupUsers { get; set; }
        public ICollection<AdmAccessGroup> AdmAccessGroups { get; set; }//adding
    }
}
