﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public abstract class Audit
    {
        public string UserCreate { get; set; }
        public DateTime DateCreate { get; set; }

        public string UserUpdate { get; set; }
        public DateTime DateUpdate { get; set; }
    }
}
