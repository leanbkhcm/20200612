﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public class GroupUserAccessGroup
    {
        //remove 
        /*[Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]*/

        [Required]
        public String GroupUserID { get; set; }         
        public AdmGroupUser AdmGroupUsers { get; set; }




        public String AccessGroupID { get; set; }
        public AdmAccessGroup AdmAccessGroups { get; set; }

    }
}
