﻿using ADM.API.Models.Detail;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SITV_LIB;

namespace ADM.API.Models.Repo.SpecialUser
{
    public class AdmSpecialUserRepo : IAdmSpecialUserRepo
    {
        private readonly DataManagementContext appDbContext;
        private readonly string KeyEnscriptPassword = "sitv";
        public AdmSpecialUserRepo(DataManagementContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        
        public async Task<IEnumerable<AdmSpecialUser>> GetSpecialUsers()
        {
            /*return await appDbContext.AdmSpecialUsers.ToListAsync();*/
            return await appDbContext.AdmSpecialUsers.Include(u => u.AdmGroupUsers).ToListAsync();
        }



        public async Task<AdmSpecialUser> GetSpecialUserById(string id)
        {

            return await appDbContext.AdmSpecialUsers
                .FirstOrDefaultAsync(u => u.UserID == id);
        }


        public async Task<AdmSpecialUser> GetSpecialUserByUserIDPass(string userId, string pass)
        {
            return await appDbContext.AdmSpecialUsers
                .FirstOrDefaultAsync(u => u.UserID.Trim().ToLower() == userId.Trim().ToLower() && u.Password==pass);
        }




        public async Task<List<SpecialUserGroupUserDetail>> GetSpecialUsersByGroupUserId(string grpUser)
        {
            var query = from f in appDbContext.AdmSpecialUsers
                        join p in appDbContext.AdmGroupUsers
                        on f.GroupUserID equals p.GroupUserID
                        where f.GroupUserID == grpUser
                        select new { f, p };

            var data = await query
                .Select(d => new SpecialUserGroupUserDetail()
                {
                    UserID = d.f.UserID,
                    Username = d.f.Username,
                    Password = d.f.Password,
                    FullName = d.f.FullName,
                    Role = d.f.Role,
                    Status = d.f.Status,
                    UserType = d.f.UserType,
                    GroupUserID = d.p.GroupUserID,
                    GroupUsername = d.p.GroupUsername,
                    GroupDescription = d.p.Description
                }).ToListAsync();
            return data;
        }



        public async Task<AdmSpecialUser> CreateSpecialUser(AdmSpecialUser user)
        {
            //user.Password = enscriptPassword(user.Password);// no using
            var result = await appDbContext.AdmSpecialUsers.AddAsync(user);
            await appDbContext.SaveChangesAsync();
            return result.Entity;
        }


        public async Task<AdmSpecialUser> UpdateSpecialUser(AdmSpecialUser user)
        {
            var result = await appDbContext.AdmSpecialUsers
                .FirstOrDefaultAsync(u => u.UserID == user.UserID);

            if (result != null)
            {
                result.Username = user.Username;
                result.Password = user.Password;
                result.FullName = user.FullName;
                result.Role = user.Role;
                result.Status = user.Status;
                result.UserType = user.UserType;
                result.GroupUserID = user.GroupUserID;

                //20200614
                result.UserUpdate = user.UserUpdate;
                result.DateUpdate = user.DateUpdate;

                await appDbContext.SaveChangesAsync();
                return result;
            }
            return null;
        }



        public async Task<AdmSpecialUser> GetDescriptedSpecialUser(string userID)//adding 01/06           
        {
            var result = await appDbContext.AdmSpecialUsers
                .FirstOrDefaultAsync(u => u.UserID == userID);
            if (result != null)
            {             
                result.Password = descriptPassword(result.Password);              
                return result;
            }
            return null;
        }



        //public async Task<AdmSpecialUser> getDescriptedSpecialUser(AdmSpecialUser user)//adding 01/06           
        //{
        //    var result = await appDbContext.AdmSpecialUsers
        //        .FirstOrDefaultAsync(u => u.UserID == user.UserID);

        //    if (result != null)
        //    {
        //        result.Username = user.Username;
        //        //result.Password = user.Password;
        //        result.Password = descriptPassword(user.Password);
        //        result.FullName = user.FullName;
        //        result.Role = user.Role;
        //        result.Status = user.Status;
        //        result.UserType = user.UserType;
        //        result.GroupUserID = user.GroupUserID;
        //        await appDbContext.SaveChangesAsync();
        //        return result;
        //    }
        //    return null;
        //}



        public async Task DeleteSpecialUser(string userID)
        {
            var result = await appDbContext.AdmSpecialUsers
                .FirstOrDefaultAsync(u => u.UserID == userID);
            if (result != null)
            {
                appDbContext.AdmSpecialUsers.Remove(result);
                await appDbContext.SaveChangesAsync();
            }
        }



        public string GetEnscriptPassword(string password)
        {
            var result = enscriptPassword(password);
            return result;
        }





        /* private String enscriptPassword(string inputPassword)*/
        private String enscriptPassword(string inputPassword)
        {
            SITV_LIB.SITV_LIB lib = new SITV_LIB.SITV_LIB();
            string enscriptedPw = string.Empty;
            try {
                enscriptedPw = lib.Encrypt(inputPassword, true, KeyEnscriptPassword);
            }
            catch (Exception)
            {
                return enscriptedPw;
            }
            return enscriptedPw;
        }


        private String descriptPassword(string inputKeyPassword)
        {
            SITV_LIB.SITV_LIB lib = new SITV_LIB.SITV_LIB();
            string descriptedPw = string.Empty;
            try
            {
                descriptedPw = lib.DecodeWithKey(KeyEnscriptPassword, inputKeyPassword);
            }
            catch (Exception)
            {
                return descriptedPw;
            }
            return descriptedPw;
        }

    }
}
