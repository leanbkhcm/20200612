﻿using ADM.API.Models.Detail;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.GroupUser
{
    public class AdmGroupUserRepo : IAdmGroupUserRepo
    {
        private readonly DataManagementContext appDbContext;

        public AdmGroupUserRepo(DataManagementContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<IEnumerable<AdmGroupUser>> GetAll()
        {
            return await appDbContext.AdmGroupUsers
                .Include(g => g.GroupUserAccessGroups)
                .Include(g => g.AdmSpecialUsers)
                .ToListAsync();
            /*return await appDbContext.AdmGroupUsers.ToListAsync();*/
            /*return await appDbContext.AdmGroupUsers.Include(g => g.AdmSpecialUsers).Include(g => g.GroupUserAccessGroups).ToListAsync();*/
        }


        public async Task<IEnumerable<AdmGroupUser>> GetAllGrpUserSpecialUsers()
        {
            return await appDbContext.AdmGroupUsers
                .Include(g => g.AdmSpecialUsers)
                .ToListAsync();
        }



        public async Task<IEnumerable<AdmGroupUser>> GetAllGrpUserGUAGs()
        {
            return await appDbContext.AdmGroupUsers
                .Include(g => g.GroupUserAccessGroups)
                .ToListAsync();
        }



        public async Task<IEnumerable<AdmGroupUser>> GetAllGrpUserGUAGsByGrpID(string grpUserID)
        {
            return await appDbContext.AdmGroupUsers
                .Include(g => g.GroupUserAccessGroups)
                .Where(g => g.GroupUserID == grpUserID)
                .ToListAsync();
        }




        public async Task<IEnumerable<AdmGroupUser>> GetAllGrpUserSpecialUsersByGrpID(string grpUserID)
        {
            return await appDbContext.AdmGroupUsers
                .Include(g => g.AdmSpecialUsers)
                .Where(g=>g.GroupUserID == grpUserID)
                .ToListAsync();
        }





        public async Task<AdmGroupUser> GetGroupUserById(string id)
        {
            return await appDbContext.AdmGroupUsers
                .FirstOrDefaultAsync(e => e.GroupUserID == id);
        }


        public async    Task<List<GroupUserGUAGDetail>> GetDetailGroupUserBygrpID(string grpID)
        {
            var query = from f in appDbContext.AdmGroupUsers
                        join p in appDbContext.GroupUserAccessGroups
                        on f.GroupUserID equals p.GroupUserID
                        where f.GroupUserID == grpID
                        select new { f, p };

            var data = await query
                .Select(d => new GroupUserGUAGDetail()
                {
                    GroupUserID = d.f.GroupUserID,
                    GroupUsername = d.f.GroupUsername,
                    Description = d.f.Description,
                    OULDAP = d.f.OULDAP,
                    ProjecID = d.f.ProjectID,
                    AccessGroupID = d.p.AccessGroupID
                }).ToListAsync();
            return data;
    }


        public async Task<AdmGroupUser> Update(AdmGroupUser gUser)
        {
            var result = await appDbContext.AdmGroupUsers
                .FirstOrDefaultAsync(p => p.GroupUserID == gUser.GroupUserID);

            if (result != null)
            {
                result.GroupUserID = gUser.GroupUserID;
                result.GroupUsername = gUser.GroupUsername;
                result.Description = gUser.Description;
                result.OULDAP = gUser.OULDAP;
                result.ProjectID = gUser.ProjectID;

                //20200614
                result.UserUpdate = gUser.UserUpdate;
                result.DateUpdate = gUser.DateUpdate;

                await appDbContext.SaveChangesAsync();
                return result;
            }
            return null;
        }



        public async Task<AdmGroupUser> CreateGroupUser(AdmGroupUser gUser)
        {
            var result = await appDbContext.AdmGroupUsers.AddAsync(gUser);
            await appDbContext.SaveChangesAsync();
            return result.Entity;
        }



        public async Task DeleteGroupUser(string gUserID)
        {
            var result = await appDbContext.AdmGroupUsers
                .FirstOrDefaultAsync(g => g.GroupUserID == gUserID);
            if (result != null)
            {
                appDbContext.AdmGroupUsers.Remove(result);
                await appDbContext.SaveChangesAsync();
            }
        }
    }
}
