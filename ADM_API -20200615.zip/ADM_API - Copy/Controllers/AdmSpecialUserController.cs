﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using ADM.API.Models;
using ADM.API.Models.Detail;
using ADM.API.Models.Repo;
using ADM.API.Models.Repo.SpecialUser;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using SITV_LIB;

namespace ADM.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]

    [ApiController]
    public class AdmSpecialUserController : ControllerBase
    {
        private readonly IAdmSpecialUserRepo repo;
        public IConfiguration _configuration;

        public AdmSpecialUserController(IAdmSpecialUserRepo repo, IConfiguration config)
        {
            this.repo = repo;
            _configuration = config;
        }




        [HttpGet]
        public async Task<ActionResult> GetSpecialUsers()
        {
            try
            {
                return Ok(await repo.GetSpecialUsers());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpGet("GetSpecialUserById")]
        public async Task<ActionResult<AdmSpecialUser>> GetSpecialUserById([FromQuery]string userID)
        {
            try
            {
                var result = await repo.GetSpecialUserById(userID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }




        [HttpPost("GetEnscriptPassword")]
        public Password GetEnscriptPassword([FromBody] Password obj)
        {
            obj.Pass = repo.GetEnscriptPassword(obj.Pass);
            return obj;
        }







        /* [HttpGet("GetEnscriptPassword")]
         public string GetEnscriptPassword(string password)
         {
             var result = repo.GetEnscriptPassword(password);
             if (result == null)
             {
                 return result; // Here is one return type
             }
             return result;  // Here is another return type
         }*/




        [HttpGet("GetDescriptedSpecialUser")]
        public async Task<ActionResult<AdmSpecialUser>> GetDescriptedSpecialUser([FromQuery]string userID)
        {
            try
            {
                var result = await repo.GetDescriptedSpecialUser(userID);
                if (result == null) return NotFound();
                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }





        //[HttpGet("groupUser/{gUserId}")]
        //[HttpGet("GetUsersByGroupId/groupUserID={gUserId}")]
        [HttpGet("GetUsersByGroupId")]
        public async Task<ActionResult<List<SpecialUserGroupUserDetail>>> GetSpecialUsersByGroupUserId([FromQuery] string groupUserID)
        {
            try
            {
                var result = await repo.GetSpecialUsersByGroupUserId(groupUserID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpPost]
        public async Task<ActionResult<AdmSpecialUser>> CreateSpecialUser(AdmSpecialUser user)
        {
            try
            {
                if (user == null)
                    return BadRequest();

                var createUser = await repo.CreateSpecialUser(user);

                return CreatedAtAction(nameof(GetSpecialUserById),
                    new { id = createUser.UserID }, createUser);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error creating new Special User record");
            }
        }

        //[AllowAnonymous]
        [HttpPost("CreateUser")]
        public async Task<ActionResult<AdmSpecialUser>> CreateUser(AdmSpecialUser user)
        {
            try
            {
                if (user == null)
                    return BadRequest();

                var createUser = await repo.CreateSpecialUser(user);

                return CreatedAtAction(nameof(GetSpecialUserById),
                    new { id = createUser.UserID }, createUser);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error creating new Special User record");
            }
        }

        /* [AllowAnonymous]
         [HttpPost("userLogin")]
         public async Task<string> userLogin([FromBody] AdmSpecialUser specialUser)
         {
             var user = await repo.GetSpecialUserByUserIDPass(specialUser.UserID, specialUser.Password);
             if (user != null)
             {
                 return GetToken(user);
             }               
             return "Login Failed";
         }*/



        [AllowAnonymous]// temp re-use on local
        [HttpPost("isLoginValid")]
        public async Task<bool> isLoginValid([FromBody] AdmSpecialUser specialUser)
        {
            var user = await repo.GetSpecialUserByUserIDPass(specialUser.UserID, specialUser.Password);
            if (user != null)
            {
                return true;
            }
            return false;
        }


        public string GetToken(AdmSpecialUser user)
        {            
                    var claims = new[] {
                               new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                               new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                               new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                               new Claim("UserID", user.UserID),
                               new Claim("Username", user.Username)
                              };
                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                    var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(_configuration["Jwt:Issuer"], _configuration["Jwt:Audience"], claims, expires: DateTime.UtcNow.AddMinutes(45), signingCredentials: signIn);
                    string tokenCode = "Bearer " + new JwtSecurityTokenHandler().WriteToken(token);
                    return tokenCode;
        }




        /*[HttpPut("UpdateUser/SpecialUserID={id}")]
        public async Task<ActionResult<AdmSpecialUser>> UpdateSpecialUser(string id, AdmSpecialUser user)*/
        [HttpPut("UpdateUser")]
        public async Task<ActionResult<AdmSpecialUser>> UpdateSpecialUser([FromQuery]string userId, [FromBody]AdmSpecialUser user)
        {
            try
            {
                if (userId != user.UserID)
                    return BadRequest("SpecialUserID mismatch");

                var functToUpdate = await repo.GetSpecialUserById(userId);

                if (functToUpdate == null)
                    return NotFound($"Special User with Id = {userId} not found");

                return await repo.UpdateSpecialUser(user);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }




        [HttpPut("UpdateUser/{userID}")]
        public async Task<ActionResult<AdmSpecialUser>> UpdateUser(string userID, [FromBody] AdmSpecialUser user)
        {
            try
            {
                if (userID != user.UserID)
                    return BadRequest("FunctionID mismatch");

                var functToUpdate = await repo.GetSpecialUserById(userID);

                if (functToUpdate == null)
                    return NotFound($"Special User with Id = {userID} not found");

                return await repo.UpdateSpecialUser(user);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }


    /*    [HttpPut("{id}")]
        public IActionResult UpdateOwner(Guid id, [FromBody]OwnerForUpdateDto owner)*/




        [HttpDelete("DeleteSpecialUser")]
        public async Task<ActionResult<AdmSpecialUser>> DeleteSpecialUser([FromQuery]string userId)
        {
            try
            {
                var userToDelete = await repo.GetSpecialUserById(userId);

                if (userToDelete == null)
                {
                    return NotFound($"Special User with Id = {userId} not found");
                }

                await repo.DeleteSpecialUser(userId);
                return userToDelete;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }


    }
}