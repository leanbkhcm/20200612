﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ADM.API.Models;
using ADM.API.Models.Detail;
using ADM.API.Models.Repo;
using ADM.API.Models.Repo.Function;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace ADM.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AdmFunctionController : ControllerBase
    {
        private readonly IAdmFunctionRepo funcRepository;

        public AdmFunctionController(IAdmFunctionRepo functionRepository)
        {
            this.funcRepository = functionRepository;
        }


        [HttpGet]
        public async Task<ActionResult> GetAll()
        {
            try
            {
                return Ok(await funcRepository.GetAll());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        
        [HttpGet("GetAllFuncCommandsByFuncID")]
        public async Task<ActionResult> GetAllFuncCommandsByFuncID([FromQuery]string funcID)
        {
            try
            {
                return Ok(await funcRepository.GetAllFuncCommandsByFuncID(funcID));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }


        [HttpGet("GetAllFuncCommandsByProjectID")]
        public async Task<ActionResult> GetAllFuncCommandsByProjectID([FromQuery]string projectID)
        {
            try
            {
                return Ok(await funcRepository.GetAllFuncCommandsByProjectID(projectID));
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    e.Message);
            }
        }




        //adding 20200605      
        [HttpGet("GetAllFuncCommandsByProjectIDAndAccessGroupID")]
        public async Task<ActionResult> GetAllFuncCommandsByProjectIDAndAccessGroupID([FromQuery] string projectID, [FromQuery] string accessGrpId)
        {
            try
            {
                return Ok(await funcRepository.GetAllFuncCommandsByProjectID(projectID));
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    e.Message);
            }
        }



        [HttpGet("GetAllFunctionCommands")]
        public async Task<ActionResult> GetAllFunctionCommands()
        {
            try
            {
                return Ok(await funcRepository.GetAllFunctionCommands());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }







        [HttpGet("{functID}")]
        public async Task<ActionResult<AdmFunction>> GetFunctionByID(string functID)
        {
            try
            {
                var result = await funcRepository.GetFunctionByID(functID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        //[HttpGet("{functionID}/detail")]
        //[HttpGet("functionID={functionID}")]
        [HttpGet("GetFunctionByID")]
        public async Task<ActionResult<List<FunctionProjectDetail>>> GetDetailFunctionByID([FromQuery] string functionID)
        {
            try
            {
                var result = await funcRepository.GetDetailFunctionByID(functionID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }


        //[HttpGet("project/projectID={projectID}")]
        //[HttpGet("projectID={projectID}")]
        [HttpGet("GetFunctionsByProjectID")]
        public async Task<ActionResult<List<FunctionProjectDetail>>> GetAllFunctionsByProjectID([FromQuery] string id)
        {
            try
            {
                var result = await funcRepository.GetAllFunctionsByProjectID(id);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }





        //[HttpGet("prjID={prjID}&&status={status}")]
        [HttpGet("GetFunctionByProjectIDandStatus")]
        public async Task<ActionResult<List<FunctionProjectDetail>>> GetFunctionByProjectIDandStatus([FromQuery]string prjID, [FromQuery] string status)
        {
            try
            {
                var result = await funcRepository.GetFunctionByProjectIDandStatus(prjID, status);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        //[HttpGet("GetDetailFuncAccessGrpByFuncID")]
        //public async Task<ActionResult<List<FunctionAccessGroupFunctionDetail>>> GetDetailFuncAccessGrpByFuncID([FromQuery] string functionID)
        //{
        //    try
        //    {
        //        var result = await funcRepository.GetDetailFuncAccessGrpByFuncID(functionID);

        //        if (result == null) return NotFound();

        //        return result;
        //    }
        //    catch (Exception)
        //    {
        //        return StatusCode(StatusCodes.Status500InternalServerError,
        //            "Error retrieving data from the database");
        //    }
        //}





        [HttpPost]
        public async Task<ActionResult<AdmFunction>> CreateFunction(AdmFunction func)
        {
            try
            {
                if (func == null)
                    return BadRequest();

                var createdFunc = await funcRepository.CreateFunction(func);

                return CreatedAtAction(nameof(GetFunctionByID),
                    new { functID = createdFunc.FunctionID }, createdFunc);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error creating new function record");
            }
        }





        /*  [HttpPut("game/{id}")]
          public IActionResult UpdateGame(int id, [FromBody]Game update)
          {
              //...
          }*/



        //[HttpPut("UpdateFunction/{id}")]
        [HttpPut("UpdateFunction")]
        public async Task<ActionResult<AdmFunction>> UpdateFunction([FromQuery] string funcID, [FromBody] AdmFunction func)
        {
            try
            {
                if (funcID != func.FunctionID)
                    return BadRequest("FunctionID mismatch");

                var functToUpdate = await funcRepository.GetFunctionByID(funcID);

                if (functToUpdate == null)
                    return NotFound($"function with Id = {funcID} not found");

                return await funcRepository.UpdateFunction(func);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }


        /*[HttpPut("{id}")]
        public async Task<ActionResult<AdmFunction>> UpdateFunction(string id, AdmFunction func)
        {
            try
            {
                if (id != func.FunctionID)
                    return BadRequest("FunctionID mismatch");

                var functToUpdate = await funcRepository.GetFunctionByID(id);

                if (functToUpdate == null)
                    return NotFound($"function with Id = {id} not found");

                return await funcRepository.UpdateFunction(func);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }*/




        /*        [HttpDelete("{functionID}")]
                public async Task<ActionResult<AdmFunction>> deleteFunction(string functionID)*/
        [HttpDelete("deleteFunction")]
        public async Task<ActionResult<AdmFunction>> deleteFunction([FromQuery]string functionID)
        {
            try
            {
                var funcToDelete = await funcRepository.GetFunctionByID(functionID);

                if (funcToDelete == null)
                {
                    return NotFound($"Function with Id = {functionID} not found");
                }

                await funcRepository.DeleteFunction(functionID);
                return funcToDelete;
            }
            catch (Exception e)
            {

                return StatusCode(StatusCodes.Status500InternalServerError  ,
                    "Error deleting data" + e.StackTrace + e.Message);
            }
        }

    }
}