﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ADM.API.Migrations
{
    public partial class addFKtoGrpUser : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ProjectID",
                table: "ADMGROUPUSER",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ADMGROUPUSER_ProjectID",
                table: "ADMGROUPUSER",
                column: "ProjectID");

            migrationBuilder.AddForeignKey(
                name: "FK_ADMGROUPUSER_ADMPROJECT_ProjectID",
                table: "ADMGROUPUSER",
                column: "ProjectID",
                principalTable: "ADMPROJECT",
                principalColumn: "ProjectID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ADMGROUPUSER_ADMPROJECT_ProjectID",
                table: "ADMGROUPUSER");

            migrationBuilder.DropIndex(
                name: "IX_ADMGROUPUSER_ProjectID",
                table: "ADMGROUPUSER");

            migrationBuilder.DropColumn(
                name: "ProjectID",
                table: "ADMGROUPUSER");
        }
    }
}
