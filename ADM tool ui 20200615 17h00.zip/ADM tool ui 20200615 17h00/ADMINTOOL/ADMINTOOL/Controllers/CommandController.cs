﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ADMINTOOL.Controllers
{
    public class CommandController : Controller
    {
        public IActionResult Index([FromQuery]string projectId, [FromQuery]string functionId)
        {
            if (projectId != null)
            {
                ViewBag.projectId = projectId;
            }
            if (projectId != null)
            {
                ViewBag.functionId = functionId;
            }
            return View();
        }
    }
}