﻿var root = angular.module('rootApp', ['masterApp', 'GroupUserApp']);
var app = angular.module('GroupUserApp', ['ngSanitize', 'ui.select', 'ui.bootstrap.contextMenu']);

app.controller('GroupUserCtrl', function ($scope, $http, $interval) {

    $scope.user = getSession('ee11cbb19052e40b07aac0ca060c23ee');
    $scope.user = JSON.parse($scope.user);

    $scope.currentLang = null;
    $scope.groupMenu = [];

    //Set timer to tracking language changes
    $http.get("/lang/" + currentLang + '.usergroup.json')
        .then(function (response) {
            $scope.site = response.data;
            $scope.menuInit();
        });

    $interval(function () {
        if (currentLang != $scope.currentLang) {
            $scope.currentLang = currentLang;
            $http.get("/lang/" + currentLang + '.usergroup.json')
                .then(function (response) {
                    $scope.site = response.data;
                    $scope.menuInit();
                });

        }
    }, 1000);

    // Get projects list
    $http.get(apiHost + 'admproject')
        .then(function (response) {
            $scope.projects = response.data;
            // If has parameter: project
            if (projectId != null) {
                let index = $scope.projects.findIndex(project => project.projectID === projectId);
                if ($scope.projects[index] != null) {
                    $scope.LoadGroupUser($scope.projects[index]);
                }

            }
            //.If has parameter: project
            //console.log($scope.projects);
        });
    // Load Group User
    $scope.LoadGroupUser = function (project) {
        $http.get(apiHost + 'AdmProject/GetListGrpUserByPrjID?projectID=' + project.projectID)
            .then(function (response) {
                $scope.selectedProject = project;
                $scope.userGroups = response.data;

            });
    }

    //$('#tableGroupUser').dataTable();
    // Select GroupUser
    $scope.SelectGroupUser = function (userGroup) {
        $scope.selectedUserGroup = userGroup;

        $scope.userGroupCode = userGroup.groupUserId;
        $scope.userGroupName = userGroup.groupUsername;
        $scope.userGroupDesc = userGroup.description;
        $scope.userGroupOU = userGroup.oULDAP;

    }

    // New GroupUser GroupUser
    $scope.NewGroupUser = function () {
        $('#modalGroupUser').modal('show');
        $scope.selectedUserGroup = null;
        $scope.userGroupCode = null;
        $scope.userGroupName = null;
        $scope.userGroupDesc = null;
        $scope.userGroupOU = null;

    }
    // Edit GroupUser GroupUser
    $scope.EditGroupUser = function () {
        if ($scope.selectedUserGroup == null) {
            swal($scope.site.dl_warning, $scope.site.dg_nogroup, "warning");
        }
        else {
            $('#modalGroupUser').modal('show');
        }

    }
    // Delete GroupUser GroupUser
    $scope.DeleteGroupUser = function () {
        if ($scope.selectedUserGroup == null) {
            swal($scope.site.dl_warning, $scope.site.dg_nogroup, "warning");
        }
        else {
            swal({
                title: $scope.site.dl_confirm,
                text: $scope.site.dl_notice,
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55", confirmButtonText: $scope.site.btn_ok,
                cancelButtonText: $scope.site.btncancel,
                closeOnConfirm: true,
                closeOnCancel: true
            },
                function (isConfirm) {
                    if (isConfirm) {
                        console.log($scope.selectedUserGroup);
                        $http.delete(apiHost + 'admgroupuser/DeleteGroupUser?gUserID=' + $scope.selectedUserGroup.groupUserId, null, 'application/json').then(function (response) {

                            // This function handles success

                            let index = $scope.userGroups.findIndex(group => group.groupUserId === $scope.selectedUserGroup.groupUserId);
                            $scope.userGroups.splice(index, 1);
                            $scope.selectedUserGroup = null;
                            swal($scope.site.dg_success, $scope.site.dl_deletesuccess, "success");
                            // alert(response.data);
                        }, function (response) {
                            // this function handles error
                            swal("Error!", response.data, "error");
                        });

                        //------------------

                    } else {
                        //swal("Cancelled", "Cancelled!", "error");
                    }
                });
        }
    }
    //Save changes
    $scope.SaveChanges = function () {
        // If create UserGroup
        if ($scope.selectedUserGroup == null) {
            $scope.userGroup = {};
            $scope.userGroup.groupUserID = $scope.userGroupCode;
            $scope.userGroup.groupUsername = $scope.userGroupName;
            $scope.userGroup.description = $scope.userGroupDesc;
            $scope.userGroup.ouldap = $scope.userGroupOU;
            $scope.userGroup.projectID = $scope.selectedProject.projectID;

            $scope.userGroup.userCreate = $scope.user.userID;
            $scope.userGroup.dateCreate = new Date();

            $http.post(apiHost + 'admGroupUser/', JSON.stringify($scope.userGroup), 'application/json').then(function (response) {
                // This function handles success
                //console.log(response);
                // if create successfully

                $scope.userGroup = response.data;
                $scope.userGroup.groupUserId = response.data.groupUserID;
                $scope.userGroups.push($scope.userGroup);
                $scope.userGroup = null;
                $('#modalGroupUser').modal('hide');
                swal($scope.site.dg_success, $scope.site.dg_savesuccess, "success");
                // alert(response.data);
            }, function (response) {
                // this function handles error
                if (response.status == 500) {
                    swal("Error", response.data, "error");
                }
                else {
                    swal("Error: " + response.data.title, response.data.errors.ProjectName[0], "error");
                }
                // console.log(response );
            });

            //------------------
        }
        // If update project
        else {
            $scope.userGroup = {};
            $scope.userGroup = $scope.selectedUserGroup;
            // $scope.project.projectID = $scope.projectCode;
            //$scope.userGroup.groupUserID = $scope.userGroupCode;
            $scope.userGroup.groupUsername = $scope.userGroupName;
            $scope.userGroup.description = $scope.userGroupDesc;
            $scope.userGroup.ouldap = $scope.userGroupOU;
            $scope.userGroup.projectID = $scope.selectedProject.projectID;

            $scope.userGroup.userUpdate = $scope.user.userID;
            $scope.userGroup.dateUpdate = new Date();

            $http.put(apiHost + 'AdmGroupuser/UpdateGroupUser?grpUserID=' + $scope.userGroup.groupUserID, JSON.stringify($scope.userGroup), 'application/json').then(function (response) {
                // This function handles success
                //console.log(response);
                // if update successfully
                let index = $scope.userGroups.findIndex(usrGroup => usrGroup.groupUserID === $scope.userGroup.groupUserID);
                $scope.userGroups[index] = response.data;
                $scope.userGroup = null;
                $('#modalGroupUser').modal('hide');
                swal($scope.site.dg_success, $scope.site.dg_savesuccess, "success");
                // alert(response.data);
            }, function (response) {
                // this function handles error
                if (response.status != 400) {
                    swal("Error", response.data, "error");
                }
                else {
                    swal("Error: " + response.data.title, response.data.errors.ProjectName[0], "error");
                }
                // console.log(response );
            });

            //------------------

        }
    }

    $scope.UsersList = function () {
        if ($scope.selectedProject == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noproject, "warning");
        }
        else if ($scope.selectedUserGroup == null) {
            swal($scope.site.dl_warning, $scope.site.dg_nogroup, "warning");
        }
        else {
            window.location.href = '/SpecialUser?projectId=' + $scope.selectedProject.projectID + '&groupId=' + $scope.selectedUserGroup.groupUserID;
        }

    }

    $scope.menuInit = function () {
        // Menu context
        $scope.groupMenu = [
            // NEW IMPLEMENTATION
            {
                text: $scope.site.btn_new,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.NewGroupUser();
                    console.log($itemScope.groupUser);

                }
            },
            {
                text: $scope.site.btn_edit,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.SelectGroupUser($itemScope.groupUser);
                    $scope.EditGroupUser();
                }
            },
            {
                text: $scope.site.btn_delete,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.SelectGroupUser($itemScope.groupUser);
                    $scope.DeleteGroupUser();
                }
            },
            {
                text: $scope.site.btn_userlist,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.SelectGroupUser($itemScope.groupUser);
                    $scope.UsersList();
                }
            }

        ];
        //Menu context
    }

});
app.filter('propsFilter', function () {
    return function (items, props) {
        var out = [];

        if (angular.isArray(items)) {
            var keys = Object.keys(props);

            items.forEach(function (item) {
                var itemMatches = false;

                for (var i = 0; i < keys.length; i++) {
                    var prop = keys[i];
                    var text = props[prop].toLowerCase();
                    if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
                        itemMatches = true;
                        break;
                    }
                }

                if (itemMatches) {
                    out.push(item);
                }
            });
        } else {
            // Let the output be the input untouched
            out = items;
        }

        return out;
    };
});