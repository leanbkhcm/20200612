﻿var root = angular.module('rootApp', ['masterApp', 'projectApp']);
var app = angular.module('projectApp', ['ui.bootstrap.contextMenu']);
app.controller('projectCtrl', function ($scope, $http, $interval) {
   
    $scope.currentLang = null;
    $scope.projectMenu = [];

    //Set timer to tracking language changes
    $http.get("/lang/" + currentLang + '.project.json')
        .then(function (response) {
            $scope.site = response.data;
            $scope.menuInit();
        });
    $interval(function () {
        if (currentLang != $scope.currentLang) {
            $scope.currentLang = currentLang;
            $http.get("/lang/" + currentLang + '.project.json')
                .then(function (response) {
                    $scope.site = response.data;
                    $scope.menuInit();
                });

        }
    }, 1000);

    //20200615
    $scope.StatusProject = {
        availableOptions: [
            { status: 'Active' },
            { status: 'Inactive' }
        ],
        selectedOption: { status: 'Active' } //This sets the default value of the select in the ui
    };

    $scope.selectedProject = null;

    $scope.user = getSession('ee11cbb19052e40b07aac0ca060c23ee');
    $scope.user = JSON.parse($scope.user);

    // Get projects list
    $http.get(apiHost + 'admproject')
        .then(function (response) {
            $scope.projects = response.data;
            data = response.data;
             
            //console.log($scope.projects);

        });

    //$('#tableProject').dataTable();
    // Select Project function
    $scope.SelectProject = function (project) {
        $scope.selectedProject = project;

        $scope.projectCode = project.projectID;
        $scope.projectName = project.projectName;
        $scope.projectDesc = project.description;
        $scope.projectStatus = project.status;
        $scope.projectIdx = project.idx;
    }

    // New Project function
    $scope.NewProject = function () {
        //20200615
        $scope.StatusProject.selectedOption.status = $scope.StatusProject.availableOptions[0].status;
        $("#modalProject").modal({
            backdrop: 'static',
            keyboard: false
        });

        $('#modalProject').modal('show');
        $scope.selectedProject = null;
        $scope.projectCode = null;
        $scope.projectName = null;
        $scope.projectDesc = null;
        //$scope.projectStatus = null;//removed 20200615
        $scope.projectIdx = 1;

        $scope.projectStatus = $scope.StatusProject.selectedOption.status;//20200615
    }
    // Edit Project function
    $scope.EditProject = function () {
        if ($scope.selectedProject == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noproject, "warning");
            Log($user.userID, 'PROJECT', $scope.site.dg_noproject, 'warning');
        }
        else {
            //20200615
            $scope.StatusProject.selectedOption.status = $scope.selectedProject.status;
            $("#modalProject").modal({
                backdrop: 'static',
                keyboard: false
            });

            $('#modalProject').modal('show');
        }

    }
    // Delete Project function
    $scope.DeleteProject = function () {
        if ($scope.selectedProject == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noproject, "warning");
        }
        else {
            swal({
                title: $scope.site.dl_confirm,
                text: $scope.site.dl_notice,
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55", confirmButtonText: $scope.site.btn_ok,
                cancelButtonText: $scope.site.btncancel,
                closeOnConfirm: true,
                closeOnCancel: true
            },
                function (isConfirm) {
                    if (isConfirm) {
                        $http.delete(apiHost + 'admproject/DeleteProject?prjid=' + $scope.selectedProject.projectID, null, 'application/json').then(function (response) {
                            // This function handles success
                            let index = $scope.projects.findIndex(project => project.projectID === $scope.selectedProject.projectID);
                            $scope.projects.splice(index, 1);
                            swal($scope.site.dg_success, $scope.site.dl_deletesuccess, "success");
                            // alert(response.data);
                        }, function (response) {
                            // this function handles error
                            swal("Error!", response.data, "error");
                        });

                        //------------------

                    } else {
                        //swal("Cancelled", "Cancelled!", "error");
                    }
                });
        }

    }
    //Save changes
    $scope.SaveChanges = function () {
        // If create project
        if ($scope.selectedProject == null) {
            $scope.project = {};
            $scope.project.projectID = $scope.projectCode;
            $scope.project.projectName = $scope.projectName;
            $scope.project.description = $scope.projectDesc;
            $scope.project.idx = $scope.projectIdx;
          //$scope.project.status = $scope.projectStatus;//removed 20200615
            $scope.project.status = $scope.StatusProject.selectedOption.status;//add 20200615

            $scope.project.userCreate = $scope.user.userID;
            $scope.project.dateCreate = new Date();

            $http.post(apiHost + 'admproject/', JSON.stringify($scope.project), 'application/json').then(function (response) {
                // This function handles success
                //console.log(response);
                // if create successfully
                $scope.projects.push(response.data);
              
                $scope.project = null;
                $('#modalProject').modal('hide');
                swal($scope.site.dg_success, $scope.site.dg_savesuccess, "success");
          
                // alert(response.data);
            }, function (response) {
                // this function handles error
                if (response.status == 500) {
                    swal("Error", response.data, "error");
                }
                else {
                    swal("Error: " + response.data.title, response.data.errors.ProjectName[0], "error");
                }
                // console.log(response );
            });

            //------------------
        }
        // If update project
        else {
            $scope.project = $scope.selectedProject;
            // $scope.project.projectID = $scope.projectCode;
            $scope.project.projectName = $scope.projectName;
            $scope.project.description = $scope.projectDesc;
            $scope.project.idx = $scope.projectIdx;
            //$scope.project.status = $scope.projectStatus;//removed 20200615
            $scope.project.status = $scope.StatusProject.selectedOption.status;
            $scope.project.userUpdate = $scope.user.userID;
            $scope.project.dateUpdate = new Date();

            $http.put(apiHost + 'admproject/UpdateProject?prjid=' + $scope.project.projectID, JSON.stringify($scope.project), 'application/json').then(function (response) {
                // This function handles success
                //console.log(response);
                // if update successfully
                let index = $scope.projects.findIndex(project => project.projectID === $scope.projects.projectID);
                $scope.projects[index] = response.data;
                $scope.project = null;
                $('#modalProject').modal('hide');
                swal($scope.site.dg_success, $scope.site.dg_savesuccess, "success");
                // alert(response.data);
            }, function (response) {
                // this function handles error
                if (response.status != 400) {
                    swal("Error", response.data, "error");
                }
                else {
                    swal("Error: " + response.data.title, response.data.errors.ProjectName[0], "error");
                }
                // console.log(response );
            });

            //------------------

        }

        // swal("Error", "Project has not been saved", "error");
    }

    // Functions list
    $scope.FunctionsList = function () {
        if ($scope.selectedProject == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noproject, 'warning');
        }
        else {
            window.location.href = '/Function?projectId=' + $scope.selectedProject.projectID;
        }
    }
    // User Group list
    $scope.UserGroupsList = function () {
        if ($scope.selectedProject == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noproject, 'warning');
        }
        else {
            window.location.href = '/GroupUser?projectId=' + $scope.selectedProject.projectID;
        }
    }

    $scope.menuInit = function () {
        //Context Menu
        $scope.projectMenu = [
            // NEW IMPLEMENTATION
            {
                text: $scope.site.btn_new,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.NewProject();
                    console.log($itemScope.project);

                }
            },
            {
                text: $scope.site.btn_edit,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.SelectProject($itemScope.project);
                    $scope.EditProject();
                }
            },
            {
                text: $scope.site.btn_delete,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.SelectProject($itemScope.project);
                    $scope.DeleteProject();
                }
            },
            {
                text: $scope.site.btn_functionslist,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.SelectProject($itemScope.project);
                    $scope.FunctionsList();
                }
            },
            {
                text: $scope.site.btnusergroups,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.SelectProject($itemScope.project);
                    $scope.UserGroupsList();
                }
            }

        ];
        //Menu context
    }


});