﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ADM.API.Migrations
{
    public partial class newDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ACCESSGROUPFUNCTION_ADMFUNCTION_ID",
                table: "ACCESSGROUPFUNCTION");

            migrationBuilder.DropForeignKey(
                name: "FK_ADMCOMMAND_ADMFUNCTION_FunctionID",
                table: "ADMCOMMAND");

            migrationBuilder.DropForeignKey(
                name: "FK_ADMGROUPUSER_ADMPROJECT_ProjectID",
                table: "ADMGROUPUSER");

            migrationBuilder.DropForeignKey(
                name: "FK_ADMSPECIALUSER_ADMGROUPUSER_GroupUserID",
                table: "ADMSPECIALUSER");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ACCESSGROUPFUNCTION",
                table: "ACCESSGROUPFUNCTION");

            migrationBuilder.AlterColumn<string>(
                name: "ProjectID",
                table: "ADMFUNCTION",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AlterColumn<string>(
                name: "ProjectID",
                table: "ADMACCESSGROUP",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FunctionID",
                table: "ACCESSGROUPFUNCTION",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_ACCESSGROUPFUNCTION",
                table: "ACCESSGROUPFUNCTION",
                column: "ID");

            migrationBuilder.CreateIndex(
                name: "IX_ADMACCESSGROUP_ProjectID",
                table: "ADMACCESSGROUP",
                column: "ProjectID");

            migrationBuilder.CreateIndex(
                name: "IX_ACCESSGROUPFUNCTION_FunctionID",
                table: "ACCESSGROUPFUNCTION",
                column: "FunctionID");

            migrationBuilder.AddForeignKey(
                name: "FK_ACCESSGROUPFUNCTION_ADMFUNCTION_FunctionID",
                table: "ACCESSGROUPFUNCTION",
                column: "FunctionID",
                principalTable: "ADMFUNCTION",
                principalColumn: "FunctionID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ADMACCESSGROUP_ADMPROJECT_ProjectID",
                table: "ADMACCESSGROUP",
                column: "ProjectID",
                principalTable: "ADMPROJECT",
                principalColumn: "ProjectID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ADMCOMMAND_ADMFUNCTION_FunctionID",
                table: "ADMCOMMAND",
                column: "FunctionID",
                principalTable: "ADMFUNCTION",
                principalColumn: "FunctionID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ADMGROUPUSER_ADMPROJECT_ProjectID",
                table: "ADMGROUPUSER",
                column: "ProjectID",
                principalTable: "ADMPROJECT",
                principalColumn: "ProjectID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ADMSPECIALUSER_ADMGROUPUSER_GroupUserID",
                table: "ADMSPECIALUSER",
                column: "GroupUserID",
                principalTable: "ADMGROUPUSER",
                principalColumn: "GroupUserID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ACCESSGROUPFUNCTION_ADMFUNCTION_FunctionID",
                table: "ACCESSGROUPFUNCTION");

            migrationBuilder.DropForeignKey(
                name: "FK_ADMACCESSGROUP_ADMPROJECT_ProjectID",
                table: "ADMACCESSGROUP");

            migrationBuilder.DropForeignKey(
                name: "FK_ADMCOMMAND_ADMFUNCTION_FunctionID",
                table: "ADMCOMMAND");

            migrationBuilder.DropForeignKey(
                name: "FK_ADMGROUPUSER_ADMPROJECT_ProjectID",
                table: "ADMGROUPUSER");

            migrationBuilder.DropForeignKey(
                name: "FK_ADMSPECIALUSER_ADMGROUPUSER_GroupUserID",
                table: "ADMSPECIALUSER");

            migrationBuilder.DropIndex(
                name: "IX_ADMACCESSGROUP_ProjectID",
                table: "ADMACCESSGROUP");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ACCESSGROUPFUNCTION",
                table: "ACCESSGROUPFUNCTION");

            migrationBuilder.DropIndex(
                name: "IX_ACCESSGROUPFUNCTION_FunctionID",
                table: "ACCESSGROUPFUNCTION");

            migrationBuilder.DropColumn(
                name: "FunctionID",
                table: "ACCESSGROUPFUNCTION");

            migrationBuilder.AlterColumn<string>(
                name: "ProjectID",
                table: "ADMFUNCTION",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ProjectID",
                table: "ADMACCESSGROUP",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_ACCESSGROUPFUNCTION",
                table: "ACCESSGROUPFUNCTION",
                columns: new[] { "ID", "AccessGroupID", "CommandID" });

            migrationBuilder.AddForeignKey(
                name: "FK_ACCESSGROUPFUNCTION_ADMFUNCTION_ID",
                table: "ACCESSGROUPFUNCTION",
                column: "ID",
                principalTable: "ADMFUNCTION",
                principalColumn: "FunctionID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ADMCOMMAND_ADMFUNCTION_FunctionID",
                table: "ADMCOMMAND",
                column: "FunctionID",
                principalTable: "ADMFUNCTION",
                principalColumn: "FunctionID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ADMGROUPUSER_ADMPROJECT_ProjectID",
                table: "ADMGROUPUSER",
                column: "ProjectID",
                principalTable: "ADMPROJECT",
                principalColumn: "ProjectID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ADMSPECIALUSER_ADMGROUPUSER_GroupUserID",
                table: "ADMSPECIALUSER",
                column: "GroupUserID",
                principalTable: "ADMGROUPUSER",
                principalColumn: "GroupUserID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
