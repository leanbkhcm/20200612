﻿using ADM.API.Models.Detail;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.AccessGroupFunc
{
    public class AccessGroupFunctionRepo : IAccessGroupFunctionRepo
    {
        private readonly DataManagementContext appDbContext;

        public AccessGroupFunctionRepo(DataManagementContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<IEnumerable<AccessGroupFunction>> GetAllAccessGroupFuncs()
        {
            /*return await appDbContext.AccessGroupFunctions.ToListAsync();*/
            return await appDbContext.AccessGroupFunctions.
                Include(a => a.AdmAccessGroups).
                Include(a => a.AdmFunctions).
                Include(a => a.AdmCommands).
                ToListAsync();
        }


        public async Task<IEnumerable<AccessGroupFunction>> GetAccessGroupFuncbyIDs(string funcId, string accessGrpId, string cmdId)
        {
            return await appDbContext.AccessGroupFunctions.Where(p => p.FunctionID == funcId && p.AccessGroupID == accessGrpId && p.CommandID == cmdId).ToListAsync();//edited

          /*  return await appDbContext.AccessGroupFunctions
                .FirstOrDefaultAsync(p => p.ID == funcId && p.AccessGroupID == accessGrpId && p.CommandID == cmdId);*/
        }



        public async Task<AccessGroupFunction> GetAccessGroupFuncByKeyId(string id)
        {
            return await appDbContext.AccessGroupFunctions
                .FirstOrDefaultAsync(p => p.ID == id);
        }



        public async Task<IEnumerable<AccessGroupFunction>> GetAllAccessGroupFuncsbyFuncId(string funcId)
        {
            return await appDbContext.AccessGroupFunctions.Where(p => p.FunctionID == funcId).ToListAsync();//edited
        }



        public async Task<AccessGroupFunction> CreateAccessGroupFunction(AccessGroupFunction obj)
        {
            var result = await appDbContext.AccessGroupFunctions.AddAsync(obj);
            await appDbContext.SaveChangesAsync();
            return result.Entity;
        }


        public async Task DeleteAccessGrpFunc(string id, string accessGrpId, string cmdId)  //shouldnt use
        {
            var result = await appDbContext.AccessGroupFunctions
                .FirstOrDefaultAsync(g => g.ID == id && g.AccessGroupID == accessGrpId && g.CommandID == cmdId);
            if (result != null)
            {
                appDbContext.AccessGroupFunctions.Remove(result);
                await appDbContext.SaveChangesAsync();
            }
        }

        public async Task DeleteAccessGrpFuncByKeyID(string id)
        {
            var result = await appDbContext.AccessGroupFunctions
                .FirstOrDefaultAsync(g => g.ID == id);
            if (result != null)
            {
                appDbContext.AccessGroupFunctions.Remove(result);
                await appDbContext.SaveChangesAsync();
            }
        }

        //adding 20200609
        public async Task DeleteAccessGrpFuncByAccessIDandFuncID(string accessGrpID, string functionID)
        {
            var result = await appDbContext.AccessGroupFunctions
                .Where(g => g.AccessGroupID == accessGrpID && g.FunctionID == functionID).ToListAsync();

                appDbContext.AccessGroupFunctions.RemoveRange(result);
                await appDbContext.SaveChangesAsync();
        }



        ////adding 20200608
        //public async Task DeleteAccessGrpFuncByAccessGrpIDandFuncID(string accessGrpID, string funcID){
        //    var result = await appDbContext.AccessGroupFunctions
        //        .AllAsync(g => g.AccessGroupID == accessGrpID && g.FunctionID == funcID);
        //    if (result != null)
        //    {
        //        appDbContext.AccessGroupFunctions.Remove(result);
        //        await appDbContext.SaveChangesAsync();
        //    }
        //}




        //adding
        public async Task<List<AGFAccessGroupDetail>> GetAllAGFsByAccessGrpID(string AccessGrpID)
        {
            var query = from f in appDbContext.AccessGroupFunctions
                        join p in appDbContext.AdmAccessGroups
                        on f.AccessGroupID equals p.AccessGroupID
                        where f.AccessGroupID == AccessGrpID
                        select new { f, p };

            var data = await query
                .Select(d => new AGFAccessGroupDetail()
                {
                    ID = d.f.ID,
                    AccessGroupID = d.f.AccessGroupID,
                    FunctionID = d.f.FunctionID,                   
                    CommandID = d.f.CommandID,
                    AccessGroupName = d.p.AccessGroupName
    }).ToListAsync();
            return data;

        }
    }
}
