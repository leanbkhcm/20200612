﻿using ADM.API.Models.Detail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.GroupUser
{
    public interface IAdmGroupUserRepo 
    {
        Task<IEnumerable<AdmGroupUser>> GetAll();

        Task<IEnumerable<AdmGroupUser>> GetAllGrpUserSpecialUsers();

        //20200615
        Task<List<AdmGroupUser>> GetAllGroupUsersByProjectID(string projectID);

        Task<IEnumerable<AdmGroupUser>> GetAllGrpUserSpecialUsersByGrpID(string grpUserID);


        Task<IEnumerable<AdmGroupUser>> GetAllGrpUserGUAGs();

        Task<IEnumerable<AdmGroupUser>> GetAllGrpUserGUAGsByGrpID(string grpUserID);


        Task<AdmGroupUser> GetGroupUserById(string id);

        Task<List<GroupUserGUAGDetail>> GetDetailGroupUserBygrpID(string grpID);



        Task<AdmGroupUser> Update(AdmGroupUser gUser);
        Task<AdmGroupUser> CreateGroupUser(AdmGroupUser gUser);
        Task DeleteGroupUser(string gUserID);
    }
}
