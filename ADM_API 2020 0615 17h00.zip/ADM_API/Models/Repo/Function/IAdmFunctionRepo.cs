﻿using ADM.API.Models.Detail;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.Function
{
    public interface IAdmFunctionRepo
    {
        Task<IEnumerable<AdmFunction>> GetAll();

        Task<IEnumerable<AdmFunction>> GetAllFunctionCommands();

        Task<IEnumerable<AdmFunction>> GetAllFuncCommandsByFuncID(string funcID);

        Task<IEnumerable<AdmFunction>> GetAllFuncCommandsByProjectID(string projectID);//adding

        Task<IEnumerable<AdmFunction>> GetAllFuncCommandsByProjectIDAndAccessGroupID(string projectID, string accessGrpId);//adding


        Task<AdmFunction> GetFunctionByID(string id);
        Task<List<FunctionProjectDetail>> GetDetailFunctionByID(string id);


        Task<List<FunctionProjectDetail>> GetAllFunctionsByProjectID(string projectID);

        Task<List<FunctionProjectDetail>> GetFunctionByProjectIDandStatus(string prjID, string status);

        //Task<List<FunctionAccessGroupFunctionDetail>> GetDetailFuncAccessGrpByFuncID(string funcId);




        Task<AdmFunction> CreateFunction(AdmFunction func);

        Task<AdmFunction> UpdateFunction(AdmFunction func);


        Task DeleteFunction(string funcID);


      


        //ActionResult<List<AdmFunctionDetail>> GetAdmFunctionDetails(string id);//just for test

        /*Task<AdmFunction> Get(string id);*/
        /*Task<AdmFunction> Add(AdmFunction prj);
        Task<AdmFunction> Update(AdmFunction prj);
*/
    }
}
