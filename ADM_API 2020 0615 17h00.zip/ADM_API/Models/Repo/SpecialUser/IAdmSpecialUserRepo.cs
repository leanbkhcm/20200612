﻿using ADM.API.Models.Detail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.SpecialUser
{
    public interface IAdmSpecialUserRepo
    {
        Task<IEnumerable<AdmSpecialUser>> GetSpecialUsers();
        Task<AdmSpecialUser> GetSpecialUserById(string id);


        Task<AdmSpecialUser> GetSpecialUserByUserIDPass(string userId, string pass);

        //Task<AdmSpecialUser> getDescriptedSpecialUser(AdmSpecialUser user);//adding 01/06
        Task<AdmSpecialUser> GetDescriptedSpecialUser(string userId);//adding 01/06 but no using



        Task<AdmSpecialUser> CreateSpecialUser(AdmSpecialUser user);

        string GetEnscriptPassword(string password);


        Task<List<SpecialUserGroupUserDetail>> GetSpecialUsersByGroupUserId(string grpUser);

        Task<AdmSpecialUser> UpdateSpecialUser(AdmSpecialUser user);
        
        Task DeleteSpecialUser(string userID);

        




    }
}
