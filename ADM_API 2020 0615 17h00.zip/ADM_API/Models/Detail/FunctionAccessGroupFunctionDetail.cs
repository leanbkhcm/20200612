﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class FunctionAccessGroupFunctionDetail
    {
        public String FunctionID { get; set; }         

        public String FunctionName { get; set; }
        public String Description { get; set; }
        public int Idx { get; set; }
        public String Status { get; set; }

        public String ProjectID { get; set; }
        public String AccessGroupID { get; set; }
        public String CommandID { get; set; }
        
    }
}
