﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class AccessGroupAGFDetail
    {
        public String AccessGroupID { get; set; }
        public String AccessGroupName { get; set; }
        public String Description { get; set; }

        public String ProjectID { get; set; }
        public int Idx { get; set; }
        public String Status { get; set; }
        public String FunctionID { get; set; }
        public String CommandID { get; set; }
    }
}
