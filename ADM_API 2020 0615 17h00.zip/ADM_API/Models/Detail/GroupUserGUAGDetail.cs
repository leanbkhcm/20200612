﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class GroupUserGUAGDetail
    {
        public String GroupUserID { get; set; }
        public String GroupUsername { get; set; }
        public String Description { get; set; }
        public String OULDAP { get; set; }
        public String ProjecID { get; set; }
        public String AccessGroupID { get; set; }
    }
}
