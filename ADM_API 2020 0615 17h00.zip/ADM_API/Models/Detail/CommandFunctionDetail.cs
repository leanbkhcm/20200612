﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class CommandFunctionDetail
    {
        public String CommandID { get; set; }      
        public String CommandCode { get; set; }
        public String CommandName { get; set; }
        public int Idx { get; set; }
        public String FunctionID { get; set; }
        public String FunctionName { get; set; }
        public String FunctDescription { get; set; }
    }
}
