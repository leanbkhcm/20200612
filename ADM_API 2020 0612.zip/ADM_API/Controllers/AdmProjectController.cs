﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ADM.API.Models;
using ADM.API.Models.Detail;
using ADM.API.Models.Repo;
using ADM.API.Models.Repo.AccessGroup;
using ADM.API.Models.Repo.Project;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ADM.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AdmProjectController : ControllerBase
    {
       /* private readonly DataManagementContext _context;
        private readonly IAdmProjectRepo prjRepository;

        public AdmProjectController(DataManagementContext context, IAdmProjectRepo repo)
        {
            _context = context;
            prjRepository = repo;
        }*/


        private readonly IAdmProjectRepo prjRepository;

        public AdmProjectController(IAdmProjectRepo projectRepository)
        {
            this.prjRepository = projectRepository;
        }




        [HttpGet]
        public async Task<ActionResult> GetAll()
        {
            try
            {
                return Ok(await prjRepository.GetAll());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpGet("{id}")]
        public async Task<ActionResult<AdmProject>> GetProjectByID(string id)
        {
            try
            {
                var result = await prjRepository.Get(id);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }




        [HttpGet("GetPrjByPrjID")]
        public async Task<ActionResult<AdmProject>> GetPrjByPrjID([FromQuery]string prjId)
        {
            try
            {
                var result = await prjRepository.GetPrjByPrjID(prjId);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }

        [HttpGet("GetAllProject")]
        public async Task<ActionResult<List<AdmProject>>> GetAllProject()
        {
            try
            {
                var result = await prjRepository.GetAllProject();
                if (result == null) return NotFound();
                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }

        [HttpGet("GetPrjFuncDetailByPrjID")]
        public async Task<ActionResult<List<ProjectFunctionDetail>>> GetPrjFuncDetailByPrjID([FromQuery] string projectID)
        {
            try
            {
                var result = await prjRepository.GetPrjFuncDetailByPrjID(projectID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpGet("GetListGrpUserByPrjID")]
        public async Task<ActionResult<List<ProjectGroupUserDetail>>> GetListGrpUserByPrjID([FromQuery] string projectID)
        {
            try
            {
                var result = await prjRepository.GetListGrpUserByPrjID(projectID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }





        //[AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<AdmProject>> CreateProject(AdmProject prj)
        {
            try
            {
                if (prj == null)
                    return BadRequest();

                var createdProject = await prjRepository.Add(prj);

                return CreatedAtAction(nameof(GetProjectByID),
                    new { id = createdProject.ProjectID }, createdProject);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error creating new employee record");
            }
        }



        /*[HttpPut("{id}")]
        public async Task<ActionResult<AdmProject>> UpdateProject(string id, AdmProject prj)
        {
            try
            {
                if (id != prj.ProjectID)
                    return BadRequest("ProjectID mismatch");

                var projectToUpdate = await prjRepository.Get(id);

                if (projectToUpdate == null)
                    return NotFound($"Project with Id = {id} not found");

                return await prjRepository.Update(prj);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }*/


        [HttpPut("UpdateProject")]
        public async Task<ActionResult<AdmProject>> UpdateProject([FromQuery]string prjID, [FromBody]AdmProject prj)
        {
            try
            {
                if (prjID != prj.ProjectID)
                    return BadRequest("ProjectID mismatch");

                var projectToUpdate = await prjRepository.Get(prjID);

                if (projectToUpdate == null)
                    return NotFound($"Project with Id = {prjID} not found");

                return await prjRepository.Update(prj);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }



        /*[HttpDelete("{prjID}")]
        public async Task<ActionResult<AdmProject>> DeleteProject(string prjID)*/
        [HttpDelete("DeleteProject")]
        public async Task<ActionResult<AdmProject>> DeleteProject([FromQuery]string prjID)
        {
            try
            {
                var prjToDelete = await prjRepository.Get(prjID);

                if (prjToDelete == null)
                {
                    return NotFound($"Project with Id = {prjID} not found");
                }

                await prjRepository.DeleteProject(prjID);
                return prjToDelete;
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data. " + e.InnerException );
            }
        }



        [HttpDelete("DeleteFullProject")]
        public async Task<ActionResult<AdmProject>> DeleteFullProject([FromQuery]string prjID)
        {
            try
            {
                var prjToDelete = await prjRepository.Get(prjID);

                if (prjToDelete == null)
                {
                    return NotFound($"Project with Id = {prjID} not found");
                }




                /*  var images = _context.ProductImages.Where(i => i.ProductId == productId);
                  foreach (var image in images)
                  {
                      await _storageService.DeleteFileAsync(image.ImagePath);
                  }*/




                await prjRepository.DeleteProject(prjID);
                return prjToDelete;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }
    }
}