﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ADM.API.Models;
using ADM.API.Models.Detail;
using ADM.API.Models.Repo;
using ADM.API.Models.Repo.Command;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ADM.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AdmCommandController : ControllerBase
    {
        private readonly IAdmCommandRepo commandRepository;

        public AdmCommandController(IAdmCommandRepo repo)
        {
            this.commandRepository = repo;
        }




        [HttpGet]
        public async Task<ActionResult> GetAllCommands()
        {
            try
            {
                return Ok(await commandRepository.GetAllCommands());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpGet("{id}")]
        public async Task<ActionResult<AdmCommand>> GetCommandById(string id)
        {
            try
            {
                var result = await commandRepository.GetCommandById(id);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpGet("GetCommandsByFuncID")]
        public async Task<ActionResult<List<CommandFunctionDetail>>> GetDetailCommandsByFuncID([FromQuery] string id)
        {
            try
            {
                var result = await commandRepository.GetDetailCommandsByFuncID(id);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }


        [HttpGet("GetCommandByFuncIDandCommandID")] //adding 20200608
        public async Task<ActionResult<AdmCommand>> GetCommandByFuncIDandCommandID([FromQuery] string funcID, [FromQuery] string commandID)
        {
            try
            {
                var result = await commandRepository.GetCommandByFuncIDandCommandID(funcID, commandID);
                if (result == null) return NotFound();
                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }




        [HttpGet("GetCommandAccessGrpByCommandID")]
        public async Task<ActionResult<List<CommandAccessGroupFunctionDetail>>> GetCommandAccessGrpByCommandID([FromQuery] string commandID)
        {
            try
            {
                var result = await commandRepository.GetDetailCommandAccessGrpByCommandID(commandID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }






        [HttpPost]
        public async Task<ActionResult<AdmCommand>> CreateCommand(AdmCommand cmd)
        {
            try
            {
                if (cmd == null)
                    return BadRequest();

                var createdCommand = await commandRepository.CreateCommand(cmd);

                return CreatedAtAction(nameof(GetCommandById),
                    new { id = createdCommand.CommandID }, createdCommand);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error creating new command record");
            }
        }




        /*[HttpPut("{id}")]
        public async Task<ActionResult<AdmCommand>> UpdateCommand(string id, AdmCommand cmd)
        {
            try
            {
                if (id != cmd.CommandID)
                    return BadRequest("CommandID mismatch");

                var cmdToUpdate = await commandRepository.GetCommandById(id);

                if (cmdToUpdate == null)
                    return NotFound($"Command with Id = {id} not found");

                return await commandRepository.UpdateCommand(cmd);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }*/


        [HttpPut("UpdateCommand")]
        public async Task<ActionResult<AdmCommand>> UpdateCommand([FromQuery]string cmdID, [FromBody ]AdmCommand cmd)
        {
            try
            {
                if (cmdID != cmd.CommandID)
                    return BadRequest("CommandID mismatch");

                var cmdToUpdate = await commandRepository.GetCommandById(cmdID);

                if (cmdToUpdate == null)
                    return NotFound($"Command with Id = {cmdID} not found");

                return await commandRepository.UpdateCommand(cmd);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }





        /*     [HttpDelete("{cmdID}")]
             public async Task<ActionResult<AdmCommand>> DeleteCommand(string cmdID)*/
        [HttpDelete("DeleteCommand")]
        public async Task<ActionResult<AdmCommand>> DeleteCommand([FromQuery]string cmdID)
        {
            try
            {
                var cmdToDelete = await commandRepository.GetCommandById(cmdID);

                if (cmdToDelete == null)
                {
                    return NotFound($"Command with Id = {cmdID} not found");
                }

                await commandRepository.DeleteCommand(cmdID);
                return cmdToDelete;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }

    }
}