﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ADM.API.Models;
using ADM.API.Models.Repo.GrpUserAccessGrp;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ADM.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class GroupUserAccessGroupController : ControllerBase
    {
        private readonly IGroupUserAccessGroupRepo repo;

        public GroupUserAccessGroupController(IGroupUserAccessGroupRepo repo)
        {
            this.repo = repo;
        }

        [HttpGet]
        public async Task<ActionResult> GetAllGrpUserAccessGrps()
        {
            try
            {
                return Ok(await repo.GetAllGrpUserAccessGrps());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }




        [HttpGet("GetGroupUserAccessGroupByIds")]
        public async Task<ActionResult<GroupUserAccessGroup>> GetGroupUserAccessGroupByIds([FromQuery] string grpUserId, [FromQuery] string accessGrpId)
        {
            try
            {
                var result = await repo.GetGroupUserAccessGroupByIds(grpUserId, accessGrpId);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpPost]
        public async Task<ActionResult<GroupUserAccessGroup>>   CreateGroupUserAccessGroup(GroupUserAccessGroup obj)
        {
            try
            {
                if (obj == null)
                    return BadRequest();

                var createdGroupUserAccessGroup = await repo.CreateGroupUserAccessGroup(obj);

                return CreatedAtAction(nameof(GetGroupUserAccessGroupByIds),
                    new { 
                        grpUserId = createdGroupUserAccessGroup.GroupUserID, 
                        accessGrpId = createdGroupUserAccessGroup.AccessGroupID 
                        },
                        createdGroupUserAccessGroup);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error creating new command record");
            }
        }



/*
        [HttpPut("UpdateProject")]
        public async Task<ActionResult<AdmProject>> UpdateProject([FromQuery]string prjID, [FromBody]AdmProject prj)
        {
            try
            {
                if (prjID != prj.ProjectID)
                    return BadRequest("ProjectID mismatch");

                var projectToUpdate = await prjRepository.Get(prjID);

                if (projectToUpdate == null)
                    return NotFound($"Project with Id = {prjID} not found");

                return await prjRepository.Update(prj);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }*/



        [HttpDelete("DeleteGrpUserAccessGrp")]
        public async Task<ActionResult<GroupUserAccessGroup>> DeleteGrpUserAccessGrp([FromQuery]string grpUserId, [FromQuery]string accessGrpId)
        {
            try
            {
                var grpToDelete = await repo.GetGroupUserAccessGroupByIds(grpUserId, accessGrpId);

                if (grpToDelete == null)
                {
                    return NotFound($"GroupUser AccessGroup with Ids = {grpUserId}, {accessGrpId} not found");
                }

                await repo.DeleteGroupUserAccessGroup(grpUserId, accessGrpId);
                return grpToDelete;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }
    }
}