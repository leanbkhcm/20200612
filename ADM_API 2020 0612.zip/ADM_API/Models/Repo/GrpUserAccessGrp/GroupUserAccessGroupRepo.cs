﻿using ADM.API.Models.Detail;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.GrpUserAccessGrp
{
    public class GroupUserAccessGroupRepo : IGroupUserAccessGroupRepo
    {
        private readonly DataManagementContext appDbContext;

        public GroupUserAccessGroupRepo(DataManagementContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<IEnumerable<GroupUserAccessGroup>> GetAllGrpUserAccessGrps()
        {
            /*return await appDbContext.GroupUserAccessGroups.ToListAsync();*/
            return await appDbContext.GroupUserAccessGroups.Include(g => g.AdmGroupUsers).Include(g => g.AdmAccessGroups).ToListAsync();
        }

        public async Task<GroupUserAccessGroup> GetGroupUserAccessGroupByIds(string grpUserId, string accessGrpId)
        {
            return await appDbContext.GroupUserAccessGroups
                .FirstOrDefaultAsync(p => p.GroupUserID == grpUserId && p.AccessGroupID == accessGrpId);
        }

        public async Task<GroupUserAccessGroup> CreateGroupUserAccessGroup(GroupUserAccessGroup obj)
        {
            var result = await appDbContext.GroupUserAccessGroups.AddAsync(obj);
            await appDbContext.SaveChangesAsync();
            return result.Entity;
        }


        public async Task DeleteGroupUserAccessGroup(string grpUserId, string accessGrpId)
        {
            var result = await appDbContext.GroupUserAccessGroups
                .FirstOrDefaultAsync(g => g.GroupUserID == grpUserId && g.AccessGroupID == accessGrpId);
            if (result != null)
            {
                appDbContext.GroupUserAccessGroups.Remove(result);
                await appDbContext.SaveChangesAsync();
            }
        }



        public async Task<GroupUserAccessGroup> UpdGrpUserAccessGrp(GroupUserAccessGroup obj)
        {
            var result = await appDbContext.GroupUserAccessGroups
                .FirstOrDefaultAsync(p => p.GroupUserID == obj.GroupUserID && p.AccessGroupID == obj.AccessGroupID);

            if (result != null)
            {
                result.GroupUserID = obj.GroupUserID;
                result.AccessGroupID = obj.AccessGroupID;
                await appDbContext.SaveChangesAsync();
                return result;
            }

            return null;
        }

    }
}
