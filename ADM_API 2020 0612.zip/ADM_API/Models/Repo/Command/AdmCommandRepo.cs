﻿using ADM.API.Models.Detail;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.Command
{
    public class AdmCommandRepo : IAdmCommandRepo
    {
        private readonly DataManagementContext appDbContext;

        public AdmCommandRepo(DataManagementContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }


        public async Task<IEnumerable<AdmCommand>> GetAllCommands()
        {
            /*return await appDbContext.AdmCommands.ToListAsync();*/
       
            return await appDbContext.AdmCommands.Include(c => c.AccessGroupFunctions).Include(c => c.AdmFunction).ToListAsync();
        }


        public async Task<AdmCommand> GetCommandById(string commandID)
        {
            return await appDbContext.AdmCommands
                .FirstOrDefaultAsync(p => p.CommandID == commandID);
        }




        //add 20200608
        public async Task<AdmCommand> GetCommandByFuncIDandCommandID(string funcID, string cmdId) {
            return await appDbContext.AdmCommands
           .FirstOrDefaultAsync(p => p.CommandID == cmdId && p.FunctionID == funcID);
        }


        public async Task<List<CommandFunctionDetail>> GetDetailCommandsByFuncID(string funcID)
        {
            var query = from c in appDbContext.AdmCommands
                        join f in appDbContext.AdmFunctions
                        on c.FunctionID equals f.FunctionID
                        where c.FunctionID == funcID
                        select new { c, f };

            var data = await query
                .Select(d => new CommandFunctionDetail()
                {
                    CommandID = d.c.CommandID,
                    CommandCode = d.c.CommandCode,
                    CommandName = d.c.CommandName,
                    Idx = d.c.Idx,
                    FunctionID = d.c.FunctionID,
                    FunctionName = d.f.FunctionName,
                    FunctDescription = d.f.Description,
                }).ToListAsync();
            return data;
        }


     /*   public String CommandID { get; set; }
        public String CommandCode { get; set; }
        public String CommandName { get; set; }
        public int Idx { get; set; }
        public String FunctionID { get; set; }
        public String FunctionName { get; set; }
        public String FunctDescription { get; set; }*/




        public async Task<AdmCommand> CreateCommand(AdmCommand cmd)
        {
            var result = await appDbContext.AdmCommands.AddAsync(cmd);
            await appDbContext.SaveChangesAsync();
            return result.Entity;
        }


        public async Task<AdmCommand> UpdateCommand(AdmCommand command)
        {
            var result = await appDbContext.AdmCommands
                .FirstOrDefaultAsync(u => u.CommandID == command.CommandID);

            if (result != null)
            {
                result.CommandID = command.CommandID;
                result.CommandCode = command.CommandCode;
                result.CommandName = command.CommandName;
                result.Idx = command.Idx;
                result.FunctionID = command.FunctionID;
                await appDbContext.SaveChangesAsync();
                return result;
            }
            return null;
        }



        public async Task DeleteCommand(string cmdID)
        {
            var result = await appDbContext.AdmCommands
                .FirstOrDefaultAsync(p => p.CommandID == cmdID);
            if (result != null)
            {
                appDbContext.AdmCommands.Remove(result);
                await appDbContext.SaveChangesAsync();
            }
        }

        public async    Task<List<CommandAccessGroupFunctionDetail>> GetDetailCommandAccessGrpByCommandID(string commandID)
        {
            var query = from f in appDbContext.AdmCommands
                        join p in appDbContext.AccessGroupFunctions
                        on f.CommandID equals p.CommandID
                        where f.CommandID == commandID
                        select new { f, p };

            var data = await query
                .Select(d => new CommandAccessGroupFunctionDetail()
                {
                    CommandID = d.f.CommandID,
                    CommandCode = d.f.CommandCode,
                    CommandName = d.f.CommandName,
                    Idx = d.f.Idx,
                    FunctionID = d.f.FunctionID,
                    AccessGroupID = d.p.AccessGroupID                    
                }).ToListAsync();
            return data;
    }




    }
}
