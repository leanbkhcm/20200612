﻿using ADM.API.Models.Detail;
using ADM.API.Models.Repo.Function;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.Project
{
    public class AdmProjectRepo : IAdmProjectRepo
    {
        private readonly DataManagementContext appDbContext;
        //private readonly IAdmFunctionRepo functionRepo;//adding

        public AdmProjectRepo(DataManagementContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<List<AdmProject>> GetAllProject()
        {
            var project = await appDbContext.AdmProjects
                        .ToListAsync();
            return project;
        }

        public async Task<List<AdmProject>> GetAll()
        {
            var projectFunctionDetail = await appDbContext.AdmProjects
                        .Include(p => p.AdmFunctions)
                        .ToListAsync();
            return projectFunctionDetail;
        }


        public async Task<AdmProject> GetPrjByPrjID(string id)
        {
            return await appDbContext.AdmProjects
                .Include(p => p.AdmFunctions)
                .Include(p => p.AdmAccessGroups) //adding
                .FirstOrDefaultAsync(p => p.ProjectID == id);
        }


        public async Task<AdmProject> Get(string id)
        {
            return await appDbContext.AdmProjects
                .FirstOrDefaultAsync(p => p.ProjectID == id);
        }



        public async Task<List<ProjectFunctionDetail>> GetPrjFuncDetailByPrjID(string projectID)
        {
            var query = from f in appDbContext.AdmProjects
                        join p in appDbContext.AdmFunctions
                        on f.ProjectID equals p.ProjectID
                        where f.ProjectID == projectID
                        select new { f, p };

            var data = await query
                .Select(d => new ProjectFunctionDetail()
                {
                    ProjectID = d.f.ProjectID,
                    ProjectName = d.f.ProjectName,
                    Description = d.f.Description,
                    Idx = d.f.Idx,
                    Status = d.f.Status,
                    FunctionID = d.p.FunctionID,
                    FunctionName = d.p.FunctionName
                }).ToListAsync();
            return data;
        }



        public async Task<List<ProjectGroupUserDetail>> GetListGrpUserByPrjID(string projectID)
        {
            var query = from p in appDbContext.AdmProjects
                        join g in appDbContext.AdmGroupUsers
                        on p.ProjectID equals g.ProjectID
                        where p.ProjectID == projectID
                        select new { p, g };

            var data = await query
                .Select(d => new ProjectGroupUserDetail()
                {
                    GroupUserID = d.g.GroupUserID,
                    GroupUsername = d.g.GroupUsername,
                    Description = d.g.Description,
                    OULDAP = d.g.OULDAP,
                    ProjectID = d.g.ProjectID,
                    ProjectName = d.p.ProjectName
                }).ToListAsync();
            return data;
        }


        public async Task<AdmProject> Add(AdmProject prj)
        {
            var result = await appDbContext.AdmProjects.AddAsync(prj);
            await appDbContext.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<AdmProject> Update(AdmProject prj)
        {
            var result = await appDbContext.AdmProjects
                .FirstOrDefaultAsync(p => p.ProjectID == prj.ProjectID);

            if (result != null)
            {
                result.ProjectName = prj.ProjectName;
                result.Description = prj.Description;
                result.Idx = prj.Idx;
                result.Status = prj.Status;
                
                await appDbContext.SaveChangesAsync();

                return result;
            }

            return null;
        }

        public async Task DeleteProject(string prjID)
        {
            var result = await appDbContext.AdmProjects
                .FirstOrDefaultAsync(p => p.ProjectID == prjID);
            if (result != null)
            {


               /* var listFuncs = appDbContext.AdmFunctions.Where(i => i.ProjectID == prjID);
                foreach (var func in listFuncs)
                {
                    await functionRepo.DeleteFunction(func.FunctionID);
                }*/


                appDbContext.AdmProjects.Remove(result);
                await appDbContext.SaveChangesAsync();
            }
        }
    }
}
