﻿using ADM.API.Models.Detail;
using ADM.API.Models.Repo.Command;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.Function
{
    public class AdmFunctionRepo : IAdmFunctionRepo
    {
        private readonly DataManagementContext appDbContext;

        public AdmFunctionRepo(DataManagementContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }


        /*private readonly DataManagementContext appDbContext;
        private readonly IAdmCommandRepo commandRepo;

        public AdmFunctionRepo(DataManagementContext appplicationDbContext, IAdmCommandRepo commandRepository)
        {
            appDbContext = appplicationDbContext;
            commandRepo = commandRepository;
        }*/



        public async Task<IEnumerable<AdmFunction>> GetAll()
        {
            /*return await appDbContext.AdmFunctions.ToListAsync();*/
            /*return await appDbContext.AdmFunctions.Include(f => f.AdmCommands).Include(f => f.AccessGroupFunctions).ToListAsync();*/
            return await appDbContext.AdmFunctions
                .Include(f => f.AccessGroupFunctions)
                .Include(f => f.AdmCommands)
                .ToListAsync();
        }


        public async Task<IEnumerable<AdmFunction>> GetAllFunctionCommands()
        {            
            return await appDbContext.AdmFunctions
                .Include(f => f.AdmCommands)
                .ToListAsync();
        }



        public async Task<IEnumerable<AdmFunction>> GetAllFuncCommandsByFuncID(string funcID)
        {
            return await appDbContext.AdmFunctions
                .Include(f => f.AdmCommands)
                .Where(f=>f.FunctionID == funcID)
                .ToListAsync();
        }


        public async Task<IEnumerable<AdmFunction>> GetAllFuncCommandsByProjectID(string projectID)
        {
            return await appDbContext.AdmFunctions
                .Include(f => f.AdmCommands)
                .Where(f => f.ProjectID == projectID)
                .ToListAsync();
        }


        //adding
        public async Task<IEnumerable<AdmFunction>> GetAllFuncCommandsByProjectIDAndAccessGroupID(string projectID, string accessGrpId)
        {
            var query = from f in appDbContext.AdmFunctions
                        join c in appDbContext.AdmCommands
                            on f.FunctionID equals c.FunctionID

                        join g in appDbContext.AccessGroupFunctions
                            on f.FunctionID equals g.FunctionID

                        where (f.ProjectID == projectID && g.AccessGroupID == accessGrpId)
                        select new {f};

            var data = await query
            .Select(d => d.f).ToListAsync();
            return data;
        }




        ////adding
        //public async Task<IEnumerable<FunctionCommandDetail>> GetAllFuncCommandsByProjectID(string projectID)
        //{
        //    var GroupJoinQS = from f in appDbContext.AdmFunctions
        //                join c in appDbContext.AdmCommands
        //                on f.FunctionID equals c.FunctionID
        //                into tempCommandGrps

        //                from temp in tempCommandGrps
        //                      where temp.FunctionID == projectID

        //                select new
        //                {
        //                    Funcs = f,
        //                    Commands = temp
        //                };

        //    List<string> commmandIDlist = new List<String>();
        //    foreach (var item in GroupJoinQS)
        //                {
        //                    Console.WriteLine("FunctionID :" + item.Funcs.FunctionID);
        //                    commmandIDlist.Add(item.Commands.CommandID);                       
        //                }

        //    var data = await GroupJoinQS
        //        .Select(d => new FunctionCommandDetail()
        //        {
        //            FunctionID = d.Funcs.FunctionID,
        //            FunctionName = d.Funcs.FunctionName,
        //            ProjectID = d.Funcs.ProjectID,
        //            CommandIDs = commmandIDlist
        //        }).ToListAsync();
        //    return data;
        //}



        public async Task<AdmFunction> GetFunctionByID(string funcID)
        {
            return await appDbContext.AdmFunctions
                .FirstOrDefaultAsync(p => p.FunctionID == funcID);
        }


        public async Task<List<FunctionProjectDetail>> GetDetailFunctionByID(string funcId)
        {
            var query = from f in appDbContext.AdmFunctions
                        join p in appDbContext.AdmProjects
                        on f.ProjectID equals p.ProjectID
                        where f.FunctionID == funcId
                        select new { f, p };

            var data = await query
                .Select(d => new FunctionProjectDetail()
                {
                    FunctionID = d.f.FunctionID,
                    FunctionName = d.f.FunctionName,
                    FunctDescription = d.f.Description,
                    Idx = d.f.Idx,
                    Status = d.f.Status,
                    ProjectID = d.f.ProjectID,
                    ProjectName = d.p.ProjectName,
                    ProjectDescription = d.p.Description
                }).ToListAsync();
            return data;

        }

        public async Task<List<FunctionProjectDetail>> GetFunctionByProjectIDandStatus(string prjID, string status)
        {
            var query = from f in appDbContext.AdmFunctions
                        join p in appDbContext.AdmProjects
                        on f.ProjectID equals p.ProjectID
                        where (f.ProjectID == prjID && f.Status == status)
                        select new { f, p };

            var data = await query
                .Select(d => new FunctionProjectDetail()
                {
                    FunctionID = d.f.FunctionID,
                    FunctionName = d.f.FunctionName,
                    FunctDescription = d.f.Description,
                    Idx = d.f.Idx,
                    Status = d.f.Status,
                    ProjectID = d.f.ProjectID,
                    ProjectName = d.p.ProjectName,
                    ProjectDescription = d.p.Description
                }).ToListAsync();
            return data;

        }


        public async Task<List<FunctionProjectDetail>> GetAllFunctionsByProjectID(string projectID)
        {
            var query = from f in appDbContext.AdmFunctions
                        join p in appDbContext.AdmProjects
                        on f.ProjectID equals p.ProjectID
                        where f.ProjectID == projectID
                        select new { f, p };

            var data = await query
                .Select(d => new FunctionProjectDetail()
                {
                    FunctionID = d.f.FunctionID,
                    FunctionName = d.f.FunctionName,
                    FunctDescription = d.f.Description,
                    Idx = d.f.Idx,
                    Status = d.f.Status,
                    ProjectID = d.f.ProjectID,
                    ProjectName = d.p.ProjectName,
                    ProjectDescription = d.p.Description
                }).ToListAsync();
            return data;

        }

        /*public async Task<List<FunctionAccessGroupFunctionDetail>> GetDetailFuncAccessGrpByFuncID(string funcID)
        {
            var query = from f in appDbContext.AdmFunctions
                        join p in appDbContext.AccessGroupFunctions
                        on f.FunctionID equals p.ID
                        where f.FunctionID == funcID
                        select new { f, p };

            var data = await query
                .Select(d => new FunctionAccessGroupFunctionDetail()
                {
                    FunctionID = d.f.FunctionID,
                    FunctionName = d.f.FunctionName,
                    Description = d.f.Description,
                    Idx = d.f.Idx,
                    Status = d.f.Status,
                    ProjectID = d.f.ProjectID,
                    AccessGroupID = d.p.AccessGroupID,
                    CommandID = d.p.CommandID
                }).ToListAsync();
            return data;
        }*/


        public async Task<AdmFunction> CreateFunction(AdmFunction func)
        {
            var result = await appDbContext.AdmFunctions.AddAsync(func);
            await appDbContext.SaveChangesAsync();
            //add 4 default commands
            for (int i = 0; i < 4; i++)
            {
                AdmCommand command = new AdmCommand();
                command.CommandID = null;
                switch (i)
                {
                    case 0:
                        command.CommandCode = "New";
                        command.CommandName = "New";
                        break;
                    case 1:
                        command.CommandCode = "Query";
                        command.CommandName = "Query";
                        break;
                    case 2:
                        command.CommandCode = "Edit";
                        command.CommandName = "Edit";
                        break;
                    case 3:
                        command.CommandCode = "Delete";
                        command.CommandName = "Delete";
                        break;
                }
                        
                command.FunctionID = result.Entity.FunctionID;
                command.Idx = i;
                command.UserCreate = "Admin";
                command.DateCreate = DateTime.Now;
                await appDbContext.AdmCommands.AddAsync(command);
                await appDbContext.SaveChangesAsync();
            }
            return result.Entity;
        }



        public async Task<AdmFunction> UpdateFunction(AdmFunction func)
        {
            var result = await appDbContext.AdmFunctions
                .FirstOrDefaultAsync(p => p.FunctionID == func.FunctionID);

            if (result != null)
            {
                result.FunctionName = func.FunctionName;
                result.Description = func.Description;
                result.Idx = func.Idx;
                result.Status = func.Status;
                result.ProjectID = func.ProjectID;
                //adding others filed later
                await appDbContext.SaveChangesAsync();

                return result;
            }

            return null;
        }


        public async Task DeleteFunction(string functionID)
        {
            var result = await appDbContext.AdmFunctions
                .FirstOrDefaultAsync(p => p.FunctionID == functionID);
            if (result != null)
            {

               /* //adding
                var listCmds = appDbContext.AdmCommands.Where(i => i.FunctionID == functionID);
                foreach (var cmd in listCmds)
                {
                    await commandRepo.DeleteCommand(cmd.CommandID);
                }
                //adding*/


                appDbContext.AdmFunctions.Remove(result);
                await appDbContext.SaveChangesAsync();
            }
        }


       
    }


}
    
