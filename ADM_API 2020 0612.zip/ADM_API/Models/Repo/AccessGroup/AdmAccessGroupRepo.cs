﻿using ADM.API.Models.Detail;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.AccessGroup
{
    public class AdmAccessGroupRepo : IAdmAccessGroupRepo
    {
        private readonly DataManagementContext appDbContext;

        public AdmAccessGroupRepo(DataManagementContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }

        public async Task<IEnumerable<AdmAccessGroup>> GetAllAccessGroups()
        {
            /*return await appDbContext.AdmAccessGroups.ToListAsync();*/
            return await appDbContext.AdmAccessGroups.
                Include(g => g.GroupUserAccessGroups).
                Include(g => g.AccessGroupFunctions).
                ToListAsync();
        }



        //adding
        //public async Task<IEnumerable<AccessGroupProjectFunctionDetail>> GetAllFuncsByProjectID(string projectID)
        //{
        //    var query = from g in appDbContext.AdmAccessGroups
        //                join p in appDbContext.AdmProjects
        //                on g.ProjectID equals p.ProjectID
        //                into tempAccessGrpProject

        //                from p in tempAccessGrpProject.DefaultIfEmpty()
        //                join f in appDbContext.AdmFunctions
        //                on p.ProjectID equals f.ProjectID
        //                where g.ProjectID == projectID

        //                select new { g, p, f };

        //    var data = await query
        //        .Select(d => new AccessGroupProjectFunctionDetail()
        //        {
        //            AccessGroupID = d.g.AccessGroupID,
        //            AccessGroupName = d.g.AccessGroupName,
        //            Description = d.g.Description,
        //            ProjectID = d.g.ProjectID,
        //            ProjectName = d.p.ProjectName,
        //            FunctionID = d.f.FunctionID,
        //            FunctionName = d.f.FunctionName
        //        }).ToListAsync();
        //    return data;



        //    /* return await appDbContext.AdmAccessGroups.
        //         Include(g => g.AdmProjects).
        //         ThenInclude(p => p.AdmFunctions).
        //         Where(g => g.ProjectID == projectID).
        //         ToListAsync();*/
        //}

        //adding     
        public async Task<IEnumerable<AccessGroupProjectFunctionDetail>> GetAllFuncsByProjectIDandAccessGrpID(string projectID, string accessGrpID)
        {
         /*   var query = from g in appDbContext.AdmAccessGroups
                        join p in appDbContext.AdmProjects
                        on g.ProjectID equals p.ProjectID
                        into tempAccessGrpProject

                        from p in tempAccessGrpProject.DefaultIfEmpty()
                        join f in appDbContext.AdmFunctions
                        on p.ProjectID equals f.ProjectID
                        where g.ProjectID == projectID && g.AccessGroupID == accessGrpID

                        select new { g, p, f };*/


            var query = from g in appDbContext.AdmAccessGroups
                        join p in appDbContext.AdmProjects
                        on g.ProjectID equals p.ProjectID

                        join f in appDbContext.AdmFunctions
                        on p.ProjectID equals f.ProjectID

                        where g.ProjectID == projectID && g.AccessGroupID == accessGrpID

                        select new { g, p, f };

            var data = await query
                .Select(d => new AccessGroupProjectFunctionDetail()
                {
                    AccessGroupID = d.g.AccessGroupID,
                    AccessGroupName = d.g.AccessGroupName,
                    Description = d.g.Description,
                    ProjectID = d.g.ProjectID,
                    ProjectName = d.p.ProjectName,
                    FunctionID = d.f.FunctionID,
                    FunctionName = d.f.FunctionName
                }).ToListAsync();
            return data;



            /* return await appDbContext.AdmAccessGroups.
                 Include(g => g.AdmProjects).
                 ThenInclude(p => p.AdmFunctions).
                 Where(g => g.ProjectID == projectID).
                 ToListAsync();*/
        }



        //adding     
        public async Task<IEnumerable<AccessGroupProjectFunctionCommandDetail>> GetAllFuncsCommandsByProjectIDandAccessGrpID(string projectID, string accessGrpID)
        {
            var query = from g in appDbContext.AdmAccessGroups
                        join p in appDbContext.AdmProjects
                        on g.ProjectID equals p.ProjectID

                        join f in appDbContext.AdmFunctions
                        on p.ProjectID equals f.ProjectID

                        join c in appDbContext.AdmCommands
                        on f.FunctionID equals c.FunctionID

                        where g.ProjectID == projectID && g.AccessGroupID == accessGrpID
                        select new { g, p, f, c };

            var data = await query
                .Select(d => new AccessGroupProjectFunctionCommandDetail()
                {
                    AccessGroupID = d.g.AccessGroupID,
                    AccessGroupName = d.g.AccessGroupName,
                    Description = d.g.Description,
                    ProjectID = d.g.ProjectID,
                    ProjectName = d.p.ProjectName,
                    FunctionID = d.f.FunctionID,
                    FunctionName = d.f.FunctionName,
                    CommandID = d.c.CommandID,
                    CommandCode = d.c.CommandCode,
                    CommandName = d.c.CommandName
                }).ToListAsync();
            return data;
        }



        public async Task<IEnumerable<AdmAccessGroup>> GetAllAccessGrpGUAGs()
        {
            return await appDbContext.AdmAccessGroups.
                Include(g => g.GroupUserAccessGroups).
                OrderBy(g=>g.AccessGroupID).
                ToListAsync();
        }


        
        public async Task<IEnumerable<AdmAccessGroup>> GetAllAccessGrpGUAGsByAccessGrpID(string accessGrpID)
        {
            return await appDbContext.AdmAccessGroups.
                Include(g => g.GroupUserAccessGroups).
                Where(g=>g.AccessGroupID == accessGrpID).
                OrderBy(g => g.AccessGroupID).
                ToListAsync();
        }

        //adding 20200610
        public async Task<IEnumerable<AdmAccessGroup>> GetAllAccessGrpsByProjectID(string projectID)
        {
            return await appDbContext.AdmAccessGroups.
                Where(g => g.ProjectID == projectID).
                OrderBy(g => g.Idx).
                ToListAsync();
        }


        public async Task<AdmAccessGroup> GetAccessGroupbyID(string id)
        {
            return await appDbContext.AdmAccessGroups
                .FirstOrDefaultAsync(p => p.AccessGroupID == id);
        }

        public async Task<AdmAccessGroup> CreateAccessGroup(AdmAccessGroup prj)
        {
            var result = await appDbContext.AdmAccessGroups.AddAsync(prj);
            await appDbContext.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<AdmAccessGroup> UpdateAccessGroup(AdmAccessGroup ag)
        {
            var result = await appDbContext.AdmAccessGroups
                .FirstOrDefaultAsync(p => p.AccessGroupID == ag.AccessGroupID);

            if (result != null)
            {
                result.AccessGroupID = ag.AccessGroupID;
                result.AccessGroupName = ag.AccessGroupName;
                result.Description = ag.Description;
                result.ProjectID = ag.ProjectID;
                result.Idx = ag.Idx;
                result.Status = ag.Status;
                
                await appDbContext.SaveChangesAsync();

                return result;
            }

            return null;
    }

        public async Task DeleteAccessGroup(string prjID)
        {
            var result = await appDbContext.AdmAccessGroups
                .FirstOrDefaultAsync(p => p.AccessGroupID == prjID);
            if (result != null)
            {
                appDbContext.AdmAccessGroups.Remove(result);
                await appDbContext.SaveChangesAsync();
            }
        }


        public async Task<List<AccessGroupGUAGDetail>> GetAccessGrpGUAGByAccessGrpID(string accessGrpID)
        {
            var query = from f in appDbContext.AdmAccessGroups
                        join p in appDbContext.GroupUserAccessGroups
                        on f.AccessGroupID equals p.AccessGroupID
                        where f.AccessGroupID == accessGrpID
                        select new { f, p };

            var data = await query
                .Select(d => new AccessGroupGUAGDetail()
                {
                    AccessGroupID = d.f.AccessGroupID,
                    AccessGroupName = d.f.AccessGroupName,
                    Description = d.f.Description,
                    ProjectID = d.f.ProjectID,
                    Idx = d.f.Idx,
                    Status = d.f.Status,
                    GroupUserID = d.p.GroupUserID
                }).ToListAsync();
            return data;
        }


        
        public async Task<List<AccessGroupAGFDetail>> GetDetailAccessGrpFunctionByAccessGrpID(string accessGrpID)
        {
            var query = from f in appDbContext.AdmAccessGroups
                        join p in appDbContext.AccessGroupFunctions
                        on f.AccessGroupID equals p.AccessGroupID
                        where f.AccessGroupID == accessGrpID
                        select new { f, p };

            var data = await query
                .Select(d => new AccessGroupAGFDetail()
                {
                    AccessGroupID = d.f.AccessGroupID,
                    AccessGroupName = d.f.AccessGroupName,
                    Description = d.f.Description,
                    ProjectID = d.f.ProjectID,
                    Idx = d.f.Idx,
                    Status = d.f.Status,
                    FunctionID = d.p.ID,
                    CommandID = d.p.CommandID
                }).ToListAsync();
            return data;
        }


        //adding 
        public async Task<List<AccessGroupAGFDetail>> GetDetailAccessGrpFunctionByAccessGrpIDandProjectID(string accessGrpID, string projectID)
        {
            var query = from f in appDbContext.AdmAccessGroups
                        join p in appDbContext.AccessGroupFunctions
                        on f.AccessGroupID equals p.AccessGroupID
                        where f.AccessGroupID == accessGrpID && f.ProjectID == projectID
                        select new { f, p };

            var data = await query
                .Select(d => new AccessGroupAGFDetail()
                {
                    AccessGroupID = d.f.AccessGroupID,
                    AccessGroupName = d.f.AccessGroupName,
                    Description = d.f.Description,
                    ProjectID = d.f.ProjectID,
                    Idx = d.f.Idx,
                    Status = d.f.Status,
                    FunctionID = d.p.FunctionID,//edited 20200806
                    CommandID = d.p.CommandID
                }).ToListAsync();
            return data;
        }





    }
}
