﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ADM.API.Migrations
{
    public partial class changeNameFKGrpUserRev2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
