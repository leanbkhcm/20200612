﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using ADM.API.Models;
using ADM.API.Models.Repo.SpecialUser;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace ADM.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        public IConfiguration _configuration;
        private readonly IAdmSpecialUserRepo _specialUserRepo;


        public TokenController(IConfiguration config, IAdmSpecialUserRepo specialUserRepo)
        {
            _configuration = config;
            _specialUserRepo = specialUserRepo;
        }


        [HttpPost("GetToken")]
        public async Task<string> GetToken([FromBody]AdmSpecialUser _userData)
        {
            if (_userData != null && _userData.UserID != null && _userData.Password != null)
            {
                //_userData.Password = _specialUserRepo.GetEnscriptPassword(_userData.Password);
                var user = await GetUser(_userData);
                if (user != null)
                {
                    var claims = new[] {
                               new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                               new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                               new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                               new Claim("Id", user.UserID.ToString()),
                               new Claim("Name", user.Username),
                              };
                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                    var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(_configuration["Jwt:Issuer"], _configuration["Jwt:Audience"], claims, expires: DateTime.UtcNow.AddMinutes(45), signingCredentials: signIn);
                    /*return Ok(new JwtSecurityTokenHandler().WriteToken(token));*/
                    return new JwtSecurityTokenHandler().WriteToken(token);
                }
                else
                {
                    return "Invalid credentials";
                }
            }
            else
            {
                return "Generate token failed";
            }
        }

        private async Task<AdmSpecialUser> GetUser(AdmSpecialUser user)
        {
            return await _specialUserRepo.GetSpecialUserByUserIDPass(user.UserID, user.Password);
        }
    }
}