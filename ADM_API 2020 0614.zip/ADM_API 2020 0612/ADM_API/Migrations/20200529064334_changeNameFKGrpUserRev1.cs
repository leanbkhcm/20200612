﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ADM.API.Migrations
{
    public partial class changeNameFKGrpUserRev1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProjecID",
                table: "ADMGROUPUSER");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ProjectID",
                table: "ADMGROUPUSER",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
