﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public class AdmAccessGroup : Audit
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string AccessGroupID { get; set; }    
        [Required]
        public string AccessGroupName { get; set; }
        public string Description { get; set; }
        [Required]
        public string ProjectID { get; set; }
        public AdmProject AdmProjects { get; set; }//adding

        public int Idx { get; set; }//pay attention
        public string Status { get; set; }

        public /*virtual*/  ICollection<GroupUserAccessGroup> GroupUserAccessGroups { get; set; }
        public /*virtual*/ ICollection<AccessGroupFunction> AccessGroupFunctions { get; set; }
    }
}
