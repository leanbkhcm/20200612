﻿using ADM.API.Models.Detail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.AccessGroupFunc
{
    public interface IAccessGroupFunctionRepo
    {
        Task<IEnumerable<AccessGroupFunction>> GetAllAccessGroupFuncs();

        Task<IEnumerable<AccessGroupFunction>> GetAccessGroupFuncbyIDs(string funcId, string accessGrpId, string cmdId);

        Task<AccessGroupFunction> GetAccessGroupFuncByKeyId(string id);

        Task<IEnumerable<AccessGroupFunction>> GetAllAccessGroupFuncsbyFuncId(string funcId);

        Task<AccessGroupFunction> CreateAccessGroupFunction(AccessGroupFunction obj);

        Task DeleteAccessGrpFunc(string id, string accessGrpId, string cmdId);//shouldnt use

        Task DeleteAccessGrpFuncByKeyID(string id);

        //adding 20200609
        Task DeleteAccessGrpFuncByAccessIDandFuncID(string accessGrpID, string functionID);


        ////adding 20200608
        //Task DeleteAccessGrpFuncByAccessGrpIDandFuncID(string accessGrpID, string funcID);


        //adding
        Task<List<AGFAccessGroupDetail>> GetAllAGFsByAccessGrpID(string AccessGrpID);
    }
}
