﻿using ADM.API.Models.Detail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.Project
{
    public interface IAdmProjectRepo
    {
        /*Task<IEnumerable<AdmProject>> GetAll();*/
        Task<AdmProject> Get(string prjID);

        Task<List<ProjectFunctionDetail>> GetPrjFuncDetailByPrjID(string projectID);


        Task<List<AdmProject>> GetAll();
        Task<AdmProject> GetPrjByPrjID(string prjID);


        Task<List<ProjectGroupUserDetail>> GetListGrpUserByPrjID(string prjID);

        Task<List<AdmProject>> GetAllProject();

        Task<AdmProject> Add(AdmProject prj);
        Task<AdmProject> Update(AdmProject prj);
        Task DeleteProject(string prjID);




    }
}
