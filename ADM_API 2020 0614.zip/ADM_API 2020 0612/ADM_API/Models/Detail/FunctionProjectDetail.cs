﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class FunctionProjectDetail
    {
        public String FunctionID { get; set; }
        public String FunctionName { get; set; }
        public String FunctDescription { get; set; }
        public int Idx { get; set; }
        public String Status { get; set; }
        public String ProjectID { get; set; }
        public String ProjectName { get; set; }
        public String ProjectDescription { get; set; }


        /*       public AdmProject AdmProjects { get; set; }
               public AdmFunction AdmFunctions { get; set; }*/


    }
}
