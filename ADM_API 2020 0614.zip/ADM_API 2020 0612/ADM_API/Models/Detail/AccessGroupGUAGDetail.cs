﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    //should inherit Audit
    public class AccessGroupGUAGDetail
    {
        public String AccessGroupID { get; set; }       
        public String AccessGroupName { get; set; }
        public String Description { get; set; }

        public String ProjectID { get; set; }
        public int Idx { get; set; }
        public String Status { get; set; }
        public String GroupUserID { get; set; }
    }
}
