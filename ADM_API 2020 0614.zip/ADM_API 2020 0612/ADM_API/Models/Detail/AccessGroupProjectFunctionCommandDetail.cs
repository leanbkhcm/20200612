﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class AccessGroupProjectFunctionCommandDetail
    {
        public string AccessGroupID { get; set; }
        public string AccessGroupName { get; set; }
        public string Description { get; set; }
        public string ProjectID { get; set; }
        public string ProjectName { get; set; }

        public string FunctionID { get; set; }
        public string FunctionName { get; set; }

        public string CommandID { get; set; }
        public string CommandCode { get; set; }
        public string CommandName { get; set; }
    }
}
