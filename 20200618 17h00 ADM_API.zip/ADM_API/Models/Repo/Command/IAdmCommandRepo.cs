﻿using ADM.API.Models.Detail;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.Command
{
    public interface IAdmCommandRepo
    {
        Task<IEnumerable<AdmCommand>> GetAllCommands();

        Task<AdmCommand> CreateCommand(AdmCommand command);

        Task<AdmCommand> GetCommandById(string cmdId);

        //add 20200608
        Task<AdmCommand> GetCommandByFuncIDandCommandID(string funcID, string cmdId);

        //20200615
        Task<List<AdmCommand>> GetAllCommandsByFuncID(string funcID);

        Task<List<CommandFunctionDetail>> GetDetailCommandsByFuncID(string funcID);

        Task<List<CommandAccessGroupFunctionDetail>> GetDetailCommandAccessGrpByCommandID(string commandID);

        Task<AdmCommand> UpdateCommand(AdmCommand command);


        Task DeleteCommand(string cmdID);


        
    }
}
