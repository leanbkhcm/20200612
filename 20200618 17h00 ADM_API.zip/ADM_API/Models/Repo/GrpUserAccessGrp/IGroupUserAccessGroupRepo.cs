﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.GrpUserAccessGrp
{
    public interface IGroupUserAccessGroupRepo
    {

        Task<IEnumerable<GroupUserAccessGroup>> GetAllGrpUserAccessGrps();

        //Task<List<GroupUserAccessGroup>> GetGroupUserAccessGroupByGrpID(string grpID);
        Task<GroupUserAccessGroup> GetGroupUserAccessGroupByIds(string grpUserId, string accessGrpId);

        Task<GroupUserAccessGroup> CreateGroupUserAccessGroup(GroupUserAccessGroup obj);

        Task DeleteGroupUserAccessGroup(string grpUserId, string accessGrpId);

        Task<GroupUserAccessGroup> UpdGrpUserAccessGrp(GroupUserAccessGroup obj);
    }
}
