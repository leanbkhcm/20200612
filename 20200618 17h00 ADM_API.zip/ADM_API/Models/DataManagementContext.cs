﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public class DataManagementContext : DbContext
    {
        public DataManagementContext(DbContextOptions<DataManagementContext> options)
          : base(options)
        {
        }



        public DbSet<AccessGroupFunction> AccessGroupFunctions { get; set; }
        public DbSet<AdmAccessGroup> AdmAccessGroups { get; set; }
        public DbSet<AdmCommand> AdmCommands { get; set; }
        public DbSet<AdmFunction> AdmFunctions { get; set; }


        public DbSet<AdmGroupUser> AdmGroupUsers { get; set; }
        public DbSet<AdmProject> AdmProjects { get; set; }
        public DbSet<AdmSpecialUser> AdmSpecialUsers { get; set; }
        public DbSet<GroupUserAccessGroup> GroupUserAccessGroups { get; set; }



        



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AccessGroupFunction>().ToTable("ACCESSGROUPFUNCTION");
            //modelBuilder.Entity<AccessGroupFunction>()
            //.HasKey(x => new { x.ID, x.AccessGroupID , x.CommandID});

            modelBuilder.Entity<AdmAccessGroup>().ToTable("ADMACCESSGROUP");

            modelBuilder.Entity<AdmCommand>().ToTable("ADMCOMMAND");
            //modelBuilder.Entity<AdmCommand>().HasNoKey();//pay attention

            modelBuilder.Entity<AdmFunction>().ToTable("ADMFUNCTION");

            modelBuilder.Entity<AdmGroupUser>().ToTable("ADMGROUPUSER");
            modelBuilder.Entity<AdmProject>().ToTable("ADMPROJECT");
            modelBuilder.Entity<AdmSpecialUser>().ToTable("ADMSPECIALUSER");
            modelBuilder.Entity<GroupUserAccessGroup>().ToTable("GROUPUSERACCESSGROUP");
            modelBuilder.Entity<GroupUserAccessGroup>()
            .HasKey(x => new { x.GroupUserID, x.AccessGroupID});




            modelBuilder.Entity<AdmGroupUser>()
            .HasMany(s => s.AdmSpecialUsers)
            .WithOne(g => g.AdmGroupUsers)
            .HasForeignKey("GroupUserID")
            .OnDelete(DeleteBehavior.Cascade);//adding---




            //for GroupUserAccessGroups
            modelBuilder.Entity<AdmAccessGroup>()
            .HasMany(g => g.GroupUserAccessGroups)
            .WithOne(a => a.AdmAccessGroups)
            .HasForeignKey("AccessGroupID")
            .OnDelete(DeleteBehavior.Cascade);//adding---

            modelBuilder.Entity<AdmGroupUser>()
            .HasMany(g => g.GroupUserAccessGroups)
            .WithOne(u => u.AdmGroupUsers)
            .HasForeignKey("GroupUserID")
            .OnDelete(DeleteBehavior.Cascade);//adding---






            //for AccessGroupFunctions
            /*  modelBuilder.Entity<AccessGroupFunction>()
                  .HasKey(a => a.ID);*/

            modelBuilder.Entity<AdmFunction>()
            .HasMany(g => g.AccessGroupFunctions)
            .WithOne(f => f.AdmFunctions)
            .HasForeignKey("FunctionID");//change from ID to FunctionID
            //.OnDelete(DeleteBehavior.Cascade);//adding---error

            modelBuilder.Entity<AdmAccessGroup>()
            .HasMany(g => g.AccessGroupFunctions)
            .WithOne(ag => ag.AdmAccessGroups)
            .HasForeignKey("AccessGroupID")
            .OnDelete(DeleteBehavior.Cascade);//adding---

            modelBuilder.Entity<AdmCommand>()
            .HasMany(g => g.AccessGroupFunctions)
            .WithOne(c => c.AdmCommands)
            .HasForeignKey("CommandID")
            .OnDelete(DeleteBehavior.Cascade);//adding---



            modelBuilder.Entity<AdmFunction>()
            .HasMany(g => g.AdmCommands)
            .WithOne(f => f.AdmFunction)
            .HasForeignKey("FunctionID")
            .OnDelete(DeleteBehavior.Cascade);//adding



            modelBuilder.Entity<AdmProject>()
            .HasMany(g => g.AdmGroupUsers)
            .WithOne(p => p.AdmProjects)
            .HasForeignKey("ProjectID")
            .OnDelete(DeleteBehavior.Cascade);//adding 



            //adding
            modelBuilder.Entity<AdmProject>()
           .HasMany(g => g.AdmAccessGroups)
           .WithOne(p => p.AdmProjects)
           .HasForeignKey("ProjectID");
           //.OnDelete(DeleteBehavior.Cascade);//adding error



            modelBuilder.Entity<AdmProject>()
            .HasMany(f => f.AdmFunctions)
            .WithOne(prj => prj.AdmProjects)
            .HasForeignKey("ProjectID")
            .OnDelete(DeleteBehavior.Cascade);//adding;


           


        }
    }
}
