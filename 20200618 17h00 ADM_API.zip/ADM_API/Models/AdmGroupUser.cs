﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public class AdmGroupUser : Audit
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public String GroupUserID { get; set; }         //ok

        [Required]
        public String GroupUsername { get; set; }
        public String Description { get; set; }
        public String OULDAP { get; set; }// pay attention
        public String ProjectID { get; set; }
        public AdmProject AdmProjects { get; set; }

        public /*virtual*/  ICollection<GroupUserAccessGroup> GroupUserAccessGroups { get; set; }
        public /*virtual*/  ICollection<AdmSpecialUser> AdmSpecialUsers { get; set; }

        
    }
}
