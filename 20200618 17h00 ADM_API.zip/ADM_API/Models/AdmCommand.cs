﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public class AdmCommand : Audit
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public String CommandID { get; set; }       
        public String CommandCode { get; set; }
        public String CommandName { get; set; }
        public int Idx { get; set; }//pay attention



        
        public String FunctionID { get; set; }  // in the sample, have no this column
        public AdmFunction AdmFunction { get; set; }//temp remove
        public ICollection<AccessGroupFunction> AccessGroupFunctions { get; set; }//temp remove
    }
}
