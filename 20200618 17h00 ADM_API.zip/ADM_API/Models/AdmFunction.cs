﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public class AdmFunction : Audit    
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public String FunctionID { get; set; }         

        [Required]
        public String FunctionName { get; set; }
        public String Description { get; set; }
        public int Idx { get; set; }//pay attention
        public String Status { get; set; }




        //[Required]
        public String ProjectID { get; set; }
        public AdmProject AdmProjects { get; set; }  




        public ICollection<AdmCommand> AdmCommands { get; set; }
        public ICollection<AccessGroupFunction> AccessGroupFunctions { get; set; }
    }
}
