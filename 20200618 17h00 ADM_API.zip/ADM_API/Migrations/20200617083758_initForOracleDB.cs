﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ADM.API.Migrations
{
    public partial class initForOracleDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ADMPROJECT",
                columns: table => new
                {
                    ProjectID = table.Column<string>(nullable: false),
                    UserCreate = table.Column<string>(nullable: true),
                    DateCreate = table.Column<DateTime>(nullable: false),
                    UserUpdate = table.Column<string>(nullable: true),
                    DateUpdate = table.Column<DateTime>(nullable: false),
                    ProjectName = table.Column<string>(nullable: false),
                    Description = table.Column<string>(nullable: true),
                    Idx = table.Column<int>(nullable: false),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ADMPROJECT", x => x.ProjectID);
                });

            migrationBuilder.CreateTable(
                name: "ADMACCESSGROUP",
                columns: table => new
                {
                    AccessGroupID = table.Column<string>(nullable: false),
                    UserCreate = table.Column<string>(nullable: true),
                    DateCreate = table.Column<DateTime>(nullable: false),
                    UserUpdate = table.Column<string>(nullable: true),
                    DateUpdate = table.Column<DateTime>(nullable: false),
                    AccessGroupName = table.Column<string>(nullable: false),
                    Description = table.Column<string>(nullable: true),
                    ProjectID = table.Column<string>(nullable: false),
                    Idx = table.Column<int>(nullable: false),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ADMACCESSGROUP", x => x.AccessGroupID);
                    table.ForeignKey(
                        name: "FK_ADMACCESSGROUP_ADMPROJECT_ProjectID",
                        column: x => x.ProjectID,
                        principalTable: "ADMPROJECT",
                        principalColumn: "ProjectID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ADMFUNCTION",
                columns: table => new
                {
                    FunctionID = table.Column<string>(nullable: false),
                    UserCreate = table.Column<string>(nullable: true),
                    DateCreate = table.Column<DateTime>(nullable: false),
                    UserUpdate = table.Column<string>(nullable: true),
                    DateUpdate = table.Column<DateTime>(nullable: false),
                    FunctionName = table.Column<string>(nullable: false),
                    Description = table.Column<string>(nullable: true),
                    Idx = table.Column<int>(nullable: false),
                    Status = table.Column<string>(nullable: true),
                    ProjectID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ADMFUNCTION", x => x.FunctionID);
                    table.ForeignKey(
                        name: "FK_ADMFUNCTION_ADMPROJECT_ProjectID",
                        column: x => x.ProjectID,
                        principalTable: "ADMPROJECT",
                        principalColumn: "ProjectID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ADMGROUPUSER",
                columns: table => new
                {
                    GroupUserID = table.Column<string>(nullable: false),
                    UserCreate = table.Column<string>(nullable: true),
                    DateCreate = table.Column<DateTime>(nullable: false),
                    UserUpdate = table.Column<string>(nullable: true),
                    DateUpdate = table.Column<DateTime>(nullable: false),
                    GroupUsername = table.Column<string>(nullable: false),
                    Description = table.Column<string>(nullable: true),
                    OULDAP = table.Column<string>(nullable: true),
                    ProjectID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ADMGROUPUSER", x => x.GroupUserID);
                    table.ForeignKey(
                        name: "FK_ADMGROUPUSER_ADMPROJECT_ProjectID",
                        column: x => x.ProjectID,
                        principalTable: "ADMPROJECT",
                        principalColumn: "ProjectID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ADMCOMMAND",
                columns: table => new
                {
                    CommandID = table.Column<string>(nullable: false),
                    UserCreate = table.Column<string>(nullable: true),
                    DateCreate = table.Column<DateTime>(nullable: false),
                    UserUpdate = table.Column<string>(nullable: true),
                    DateUpdate = table.Column<DateTime>(nullable: false),
                    CommandCode = table.Column<string>(nullable: true),
                    CommandName = table.Column<string>(nullable: true),
                    Idx = table.Column<int>(nullable: false),
                    FunctionID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ADMCOMMAND", x => x.CommandID);
                    table.ForeignKey(
                        name: "FK_ADMCOMMAND_ADMFUNCTION_FunctionID",
                        column: x => x.FunctionID,
                        principalTable: "ADMFUNCTION",
                        principalColumn: "FunctionID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ADMSPECIALUSER",
                columns: table => new
                {
                    UserID = table.Column<string>(nullable: false),
                    UserCreate = table.Column<string>(nullable: true),
                    DateCreate = table.Column<DateTime>(nullable: false),
                    UserUpdate = table.Column<string>(nullable: true),
                    DateUpdate = table.Column<DateTime>(nullable: false),
                    Username = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true),
                    FullName = table.Column<string>(nullable: true),
                    Role = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    UserType = table.Column<string>(nullable: true),
                    GroupUserID = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ADMSPECIALUSER", x => x.UserID);
                    table.ForeignKey(
                        name: "FK_ADMSPECIALUSER_ADMGROUPUSER_GroupUserID",
                        column: x => x.GroupUserID,
                        principalTable: "ADMGROUPUSER",
                        principalColumn: "GroupUserID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "GROUPUSERACCESSGROUP",
                columns: table => new
                {
                    GroupUserID = table.Column<string>(nullable: false),
                    AccessGroupID = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GROUPUSERACCESSGROUP", x => new { x.GroupUserID, x.AccessGroupID });
                    table.ForeignKey(
                        name: "FK_GROUPUSERACCESSGROUP_ADMACCESSGROUP_AccessGroupID",
                        column: x => x.AccessGroupID,
                        principalTable: "ADMACCESSGROUP",
                        principalColumn: "AccessGroupID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_GROUPUSERACCESSGROUP_ADMGROUPUSER_GroupUserID",
                        column: x => x.GroupUserID,
                        principalTable: "ADMGROUPUSER",
                        principalColumn: "GroupUserID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ACCESSGROUPFUNCTION",
                columns: table => new
                {
                    ID = table.Column<string>(nullable: false),
                    FunctionID = table.Column<string>(nullable: true),
                    AccessGroupID = table.Column<string>(nullable: false),
                    CommandID = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ACCESSGROUPFUNCTION", x => x.ID);
                    table.ForeignKey(
                        name: "FK_ACCESSGROUPFUNCTION_ADMACCESSGROUP_AccessGroupID",
                        column: x => x.AccessGroupID,
                        principalTable: "ADMACCESSGROUP",
                        principalColumn: "AccessGroupID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ACCESSGROUPFUNCTION_ADMCOMMAND_CommandID",
                        column: x => x.CommandID,
                        principalTable: "ADMCOMMAND",
                        principalColumn: "CommandID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ACCESSGROUPFUNCTION_ADMFUNCTION_FunctionID",
                        column: x => x.FunctionID,
                        principalTable: "ADMFUNCTION",
                        principalColumn: "FunctionID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ACCESSGROUPFUNCTION_AccessGroupID",
                table: "ACCESSGROUPFUNCTION",
                column: "AccessGroupID");

            migrationBuilder.CreateIndex(
                name: "IX_ACCESSGROUPFUNCTION_CommandID",
                table: "ACCESSGROUPFUNCTION",
                column: "CommandID");

            migrationBuilder.CreateIndex(
                name: "IX_ACCESSGROUPFUNCTION_FunctionID",
                table: "ACCESSGROUPFUNCTION",
                column: "FunctionID");

            migrationBuilder.CreateIndex(
                name: "IX_ADMACCESSGROUP_ProjectID",
                table: "ADMACCESSGROUP",
                column: "ProjectID");

            migrationBuilder.CreateIndex(
                name: "IX_ADMCOMMAND_FunctionID",
                table: "ADMCOMMAND",
                column: "FunctionID");

            migrationBuilder.CreateIndex(
                name: "IX_ADMFUNCTION_ProjectID",
                table: "ADMFUNCTION",
                column: "ProjectID");

            migrationBuilder.CreateIndex(
                name: "IX_ADMGROUPUSER_ProjectID",
                table: "ADMGROUPUSER",
                column: "ProjectID");

            migrationBuilder.CreateIndex(
                name: "IX_ADMSPECIALUSER_GroupUserID",
                table: "ADMSPECIALUSER",
                column: "GroupUserID");

            migrationBuilder.CreateIndex(
                name: "IX_GROUPUSERACCESSGROUP_AccessGroupID",
                table: "GROUPUSERACCESSGROUP",
                column: "AccessGroupID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ACCESSGROUPFUNCTION");

            migrationBuilder.DropTable(
                name: "ADMSPECIALUSER");

            migrationBuilder.DropTable(
                name: "GROUPUSERACCESSGROUP");

            migrationBuilder.DropTable(
                name: "ADMCOMMAND");

            migrationBuilder.DropTable(
                name: "ADMACCESSGROUP");

            migrationBuilder.DropTable(
                name: "ADMGROUPUSER");

            migrationBuilder.DropTable(
                name: "ADMFUNCTION");

            migrationBuilder.DropTable(
                name: "ADMPROJECT");
        }
    }
}
