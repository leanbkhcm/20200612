﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ADM.API.Models;
using ADM.API.Models.Detail;
using ADM.API.Models.Repo.AccessGroup;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ADM.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AdmAccessGroupController : ControllerBase
    {
        private readonly IAdmAccessGroupRepo repo;

        public AdmAccessGroupController(IAdmAccessGroupRepo repo)
        {
            this.repo = repo;
        }


        [HttpGet]
        public async Task<ActionResult> GetAllAccessGroups()
        {
            try
            {
                return Ok(await repo.GetAllAccessGroups());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }





        [HttpGet("GetAllAccessGrpGUAGs")]
        public async Task<ActionResult> GetAllAccessGrpGUAGs()
        {
            try
            {
                return Ok(await repo.GetAllAccessGrpGUAGs());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpGet("GetAllAccessGrpGUAGsByAccessGrpID")]
        public async Task<ActionResult> GetAllAccessGrpGUAGsByAccessGrpID(string accessGrpID)
        {
            try
            {
                return Ok(await repo.GetAllAccessGrpGUAGsByAccessGrpID(accessGrpID));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }


        //adding 20200610
        [HttpGet("GetAllAccessGrpsByProjectID")]
        public async Task<ActionResult> GetAllAccessGrpsByProjectID([FromQuery]string projectID)
        {
            try
            {
                return Ok(await repo.GetAllAccessGrpsByProjectID(projectID));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpGet("{id}")]
        public async Task<ActionResult<AdmAccessGroup>> GetAccessGroupbyID(string id)
        {
            try
            {
                var result = await repo.GetAccessGroupbyID(id);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }


        [HttpGet("GetAccessGrpFuncByAccessGrpID")]
        public async Task<ActionResult<List<AccessGroupAGFDetail>>> GetDetailAccessGrpFunctionByAccessGrpID([FromQuery] string accessGrpID)
        {
            try
            {
                var result = await repo.GetDetailAccessGrpFunctionByAccessGrpID(accessGrpID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }





        //adding 20200806
        [HttpGet("GetDetailAccessGrpFunctionByAccessGrpIDandProjectID")]
        public async Task<ActionResult<List<AccessGroupAGFDetail>>> GetDetailAccessGrpFunctionByAccessGrpIDandProjectID([FromQuery] string accessGrpID, [FromQuery] string projectID)
        {
            try
            {
                var result = await repo.GetDetailAccessGrpFunctionByAccessGrpIDandProjectID(accessGrpID, projectID);
                if (result == null) return NotFound();
                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }






        [HttpGet("GetAccessGrpGUAGByAccessGrpID")]
        public async Task<ActionResult<List<AccessGroupGUAGDetail>>> GetAccessGrpGUAGByAccessGrpID([FromQuery] string accessGrpID)
        {
            try
            {
                var result = await repo.GetAccessGrpGUAGByAccessGrpID(accessGrpID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        ////adding
        //[HttpGet("GetAllFuncsByProjectID")]
        //public async Task<ActionResult<List<AccessGroupProjectFunctionDetail>>> GetAllFuncsByProjectID([FromQuery] string projectID)
        //{
        //    try
        //    {
        //        var result = await repo.GetAllFuncsByProjectID(projectID);
        //        if (result == null) return NotFound();
        //        return Ok(result);
        //    }
        //    catch (Exception)
        //    {
        //        return StatusCode(StatusCodes.Status500InternalServerError,
        //            "Error retrieving data from the database");
        //    }
        //}



        //adding
        [HttpGet("GetAllFuncsByProjectIDandAccessGrpID")]
        public async Task<ActionResult<List<AccessGroupProjectFunctionDetail>>> GetAllFuncsByProjectIDandAccessGrpID([FromQuery] string projectID, [FromQuery] string accessGrpID)
        {
            try
            {
                var result = await repo.GetAllFuncsByProjectIDandAccessGrpID(projectID, accessGrpID);
                if (result == null) return NotFound();
                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }





        [HttpPost]
        public async Task<ActionResult<AdmAccessGroup>> CreateAccessGroup(AdmAccessGroup accGrp)
        {
            try
            {
                if (accGrp == null)
                    return BadRequest();

                var createAcessGrp = await repo.CreateAccessGroup(accGrp);

                return CreatedAtAction(nameof(GetAccessGroupbyID),
                    new { id = createAcessGrp.AccessGroupID }, createAcessGrp);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error creating new Access Group record");
            }
        }



        [HttpPut("UpdAccessGrpByAccessGrpId")]
        public async Task<ActionResult<AdmAccessGroup>> UpdAccessGrpByAccessGrpId([FromQuery]string accessGrpId, [FromBody]AdmAccessGroup accGrp)
        {
            try
            {
                if (accessGrpId != accGrp.AccessGroupID)
                    return BadRequest("Access Group ID mismatch");

                var projectToUpdate = await repo.GetAccessGroupbyID(accessGrpId);

                if (projectToUpdate == null)
                    return NotFound($"Access Group with Id = {accessGrpId} not found");

                return await repo.UpdateAccessGroup(accGrp);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }



        [HttpDelete("DeleteAccessGrpByAccessGrpID")]
        public async Task<ActionResult<AdmAccessGroup>> DeleteAccessGrpByAccessGrpID([FromQuery]string grpID)
        {
            try
            {
                var grpToDelete = await repo.GetAccessGroupbyID(grpID);

                if (grpToDelete == null)
                {
                    return NotFound($"Access Group with Id = {grpID} not found");
                }

                await repo.DeleteAccessGroup(grpID);
                return grpToDelete;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }




    }
}