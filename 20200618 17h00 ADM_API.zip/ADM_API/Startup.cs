using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADM.API.Models;
using ADM.API.Models.Repo;
using ADM.API.Models.Repo.AccessGroup;
using ADM.API.Models.Repo.AccessGroupFunc;
using ADM.API.Models.Repo.Command;
using ADM.API.Models.Repo.Function;
using ADM.API.Models.Repo.GroupUser;
using ADM.API.Models.Repo.GrpUserAccessGrp;
using ADM.API.Models.Repo.Project;
using ADM.API.Models.Repo.SpecialUser;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

namespace ADM.API
{
    public class Startup
    {
       
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));

    //        //for sql server
    //        services.AddDbContext<DataManagementContext>(opt =>
    //opt.UseOracle(Configuration["ConnectionString:myconn"]));

            //for oracle
            services.AddDbContext<DataManagementContext>(opt =>
      opt.UseOracle(Configuration["ConnectionString:myconn"]));

            services.AddScoped<IAdmFunctionRepo, AdmFunctionRepo>();
            services.AddScoped<IAdmProjectRepo, AdmProjectRepo>();

            services.AddScoped<IAdmGroupUserRepo, AdmGroupUserRepo>();
            services.AddScoped<IAdmCommandRepo, AdmCommandRepo>();

            services.AddScoped<IAdmSpecialUserRepo, AdmSpecialUserRepo>();

            services.AddScoped<IAdmAccessGroupRepo, AdmAccessGroupRepo>();
            services.AddScoped<IGroupUserAccessGroupRepo, GroupUserAccessGroupRepo>();
            services.AddScoped<IAccessGroupFunctionRepo, AccessGroupFunctionRepo>();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "My API", Version = "v1" });
            });

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
            {
                options.SaveToken = true;
                options.TokenValidationParameters = new TokenValidationParameters()
                {
                    ValidateLifetime = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    LifetimeValidator =
                    (before, expires, token, parameters) =>
                    {
                        if (before.HasValue && before.Value > DateTime.Now)
                            return false;
                        if (expires.HasValue)
                            return expires > DateTime.UtcNow;
                        ;
                        return true;
                    },

                    RequireSignedTokens = true,
                    RequireExpirationTime = true,
                    ValidAudience = Configuration["Jwt:Audience"],
                    ValidIssuer = Configuration["Jwt:Issuer"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
                };


                options.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = context =>
                    {
                        if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
                        {
                            context.Response.Headers.Add("Token-Expired", "true");
                        }
                        return Task.CompletedTask;
                    }
                };
            });

            services.AddControllers();

            services.AddControllers().AddNewtonsoftJson(options =>
            options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }



            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "HRM SITV");
            });




            app.UseRouting();
            app.UseCors("MyPolicy");
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseHttpsRedirection();

            //default of program
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
