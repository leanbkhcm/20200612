﻿using ADM.API.Models.Detail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Repo.AccessGroup
{
    public interface IAdmAccessGroupRepo
    {
        //Task<IEnumerable<AccessGroupProjectFunctionDetail>> GetAllFuncsByProjectID(string projectID);//adding
        Task<IEnumerable<AccessGroupProjectFunctionDetail>> GetAllFuncsByProjectIDandAccessGrpID(string projectID, string accessGrpID);//adding

        Task<IEnumerable<AccessGroupProjectFunctionCommandDetail>> GetAllFuncsCommandsByProjectIDandAccessGrpID(string projectID, string accessGrpID);//adding

        Task<IEnumerable<AdmAccessGroup>> GetAllAccessGroups();

        Task<IEnumerable<AdmAccessGroup>> GetAllAccessGrpGUAGs();

        Task<IEnumerable<AdmAccessGroup>> GetAllAccessGrpGUAGsByAccessGrpID(string accessGrpID);

        Task<AdmAccessGroup> GetAccessGroupbyID(string accessGrpID);

        Task<List<AccessGroupGUAGDetail>> GetAccessGrpGUAGByAccessGrpID(string accessGrpID);

        Task<List<AccessGroupAGFDetail>> GetDetailAccessGrpFunctionByAccessGrpID(string accessGrpID);

        //adding
        Task<List<AccessGroupAGFDetail>> GetDetailAccessGrpFunctionByAccessGrpIDandProjectID(string accessGrpID, string projectID);

        //adding 20200610
        Task<IEnumerable<AdmAccessGroup>> GetAllAccessGrpsByProjectID(string projectID);

        Task<AdmAccessGroup> CreateAccessGroup(AdmAccessGroup accessGrp);
        Task<AdmAccessGroup> UpdateAccessGroup(AdmAccessGroup accessGrp);
        Task DeleteAccessGroup(string accessGrpID);
        

    }
}
