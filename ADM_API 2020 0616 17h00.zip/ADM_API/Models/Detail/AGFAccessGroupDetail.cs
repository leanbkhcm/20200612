﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class AGFAccessGroupDetail
    {
        public String ID { get; set; }
        public String AccessGroupID { get; set; }
        public String FunctionID { get; set; }              
        public String CommandID { get; set; }
        public String AccessGroupName { get; set; }
    }
}
