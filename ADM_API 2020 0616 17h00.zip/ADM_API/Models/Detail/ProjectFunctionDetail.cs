﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class ProjectFunctionDetail
    {
        public String ProjectID { get; set; }     
        public String ProjectName { get; set; }
        public String Description { get; set; }
        public int Idx { get; set; }
        public String Status { get; set; }

        public String FunctionID { get; set; }        
        public String FunctionName { get; set; }
    }
}
