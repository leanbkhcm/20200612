﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models.Detail
{
    public class ProjectGroupUserDetail
    {


        public String GroupUserID { get; set; }         
        public String GroupUsername { get; set; }
        public String Description { get; set; }
        public String OULDAP { get; set; }
        public String ProjectID { get; set; }
        public String ProjectName { get; set; }
        
    }
}
