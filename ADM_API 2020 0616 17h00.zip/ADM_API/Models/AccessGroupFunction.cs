﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ADM.API.Models
{
    public class AccessGroupFunction
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required]
        public String ID { get; set; }

        public String FunctionID { get; set; }
        public AdmFunction AdmFunctions { get; set; }



        [Required]
        public String AccessGroupID { get; set; }
        public AdmAccessGroup AdmAccessGroups { get; set; }



        [Required]
        public String CommandID { get; set; }
        public AdmCommand AdmCommands { get; set; } //temp remove
        
        
    }
}
