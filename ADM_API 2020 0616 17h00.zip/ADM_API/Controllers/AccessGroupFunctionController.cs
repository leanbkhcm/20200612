﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ADM.API.Models;
using ADM.API.Models.Detail;
using ADM.API.Models.Repo.AccessGroupFunc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ADM.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AccessGroupFunctionController : ControllerBase
    {
        private readonly IAccessGroupFunctionRepo repo;

        public AccessGroupFunctionController(IAccessGroupFunctionRepo repo)
        {
            this.repo = repo;
        }




        [HttpGet]
        public async Task<ActionResult> GetAllAccessGroupFuncs()
        {
            try
            {
                return Ok(await repo.GetAllAccessGroupFuncs());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }


        [HttpGet("GetAccessGroupFuncbyIDs")]
        public async Task<ActionResult<AccessGroupFunction>> GetAccessGroupFuncbyIDs([FromQuery] string funcId, [FromQuery] string accessGrpId, [FromQuery] string cmdId)
        {
            try
            {
                var result = await repo.GetAccessGroupFuncbyIDs( funcId,  accessGrpId,  cmdId);

                if (result == null) return NotFound();

                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpGet("GetAccessGroupFuncByKeyId")]
        public async Task<ActionResult<AccessGroupFunction>> GetAccessGroupFuncByKeyId([FromQuery] string id)
        {
            try
            {
                var result = await repo.GetAccessGroupFuncByKeyId(id);
                if (result == null) return NotFound();
                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }


        
        [HttpGet("GetAllAccessGroupFuncsbyFuncId")]
        public async Task<ActionResult<AccessGroupFunction>> GetAllAccessGroupFuncsbyFuncId([FromQuery] string funcId)
        {
            try
            {
                var result = await repo.GetAllAccessGroupFuncsbyFuncId(funcId);
                if (result == null) return NotFound();
                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        //adding
        [HttpGet("GetAllAGFsByAccessGrpID")]
        public async Task<ActionResult<List<AGFAccessGroupDetail>>> GetAllAGFsByAccessGrpID([FromQuery] string accessGrpID)
        {
            try
            {
                var result = await repo.GetAllAGFsByAccessGrpID(accessGrpID);
                if (result == null) return NotFound();
                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }


        [HttpPost]
        public async Task<ActionResult<AccessGroupFunction>> CreateAccessGroupFunction(AccessGroupFunction obj) //edited because of changing PK
        {
            try
            {
                if (obj == null)
                    return BadRequest();
                var createdAccessGroupFunc = await repo.CreateAccessGroupFunction(obj);
                return CreatedAtAction(nameof(GetAccessGroupFuncbyIDs),
                    new
                    {                       
                        id = createdAccessGroupFunc.ID
                    },
                        createdAccessGroupFunc);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error creating new group record");
            }
        }



        [HttpDelete("DeleteAccessGrpFunc")] 
        public async Task<ActionResult<AccessGroupFunction>> DeleteAccessGrpFunc([FromQuery]string id, [FromQuery] string accessGrpId, [FromQuery] string cmdId)
        {
            try
            {
                var grpToDelete = await repo.GetAccessGroupFuncbyIDs(id,  accessGrpId,  cmdId);

                if (grpToDelete == null)
                {
                    return NotFound($" AccessGroup Function with Ids = {id}, {accessGrpId}, {cmdId} not found");
                }

                await repo.DeleteAccessGrpFunc(id, accessGrpId, cmdId);
                return Ok(grpToDelete);//edited
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }

        //add 20200609
        [HttpDelete("DeleteAccessGrpFuncByAccessIDandFuncID")]
        public async Task<ActionResult<AccessGroupFunction>> DeleteAccessGrpFuncByAccessIDandFuncID([FromQuery] string accessGrpID, [FromQuery] string functionID)
        {
            try
            {
                await repo.DeleteAccessGrpFuncByAccessIDandFuncID(accessGrpID, functionID);
                return Ok();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }



        [HttpDelete("DeleteAccessGrpFuncByKeyID")]
        public async Task<ActionResult<AccessGroupFunction>> DeleteAccessGrpFuncByKeyID([FromQuery]string id)
        {
            try
            {
                var grpToDelete = await repo.GetAccessGroupFuncByKeyId(id);

                if (grpToDelete == null)
                {
                    return NotFound($" AccessGroup Function with Ids = {id} not found");
                }

                await repo.DeleteAccessGrpFuncByKeyID(id);
                return Ok(grpToDelete);//edited
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }

    }
}