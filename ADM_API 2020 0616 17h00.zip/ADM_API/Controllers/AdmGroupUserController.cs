﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ADM.API.Models;
using ADM.API.Models.Detail;
using ADM.API.Models.Repo;
using ADM.API.Models.Repo.GroupUser;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace ADM.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AdmGroupUserController : ControllerBase
    {
        private readonly IAdmGroupUserRepo groupUserRepo;

        public AdmGroupUserController(IAdmGroupUserRepo repo)
        {
            this.groupUserRepo = repo;
        }

        [HttpGet]
        public async Task<ActionResult> GetAll()
        {
            try
            {
                return Ok(await groupUserRepo.GetAll());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpGet("GetAllGrpUserSpecialUsers")]
        public async Task<ActionResult> GetAllGrpUserSpecialUsers()
        {
            try
            {
                return Ok(await groupUserRepo.GetAllGrpUserSpecialUsers());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }




        [HttpGet("GetAllGrpUserGUAGs")]
        public async Task<ActionResult> GetAllGrpUserGUAGs()
        {
            try
            {
                return Ok(await groupUserRepo.GetAllGrpUserGUAGs());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }


        //20200615

        [HttpGet("GetAllGroupUsersByProjectID")]
        public async Task<ActionResult<List<AdmGroupUser>>> GetAllGroupUsersByProjectID([FromQuery] string projectID)
        {
            try
            {
                var result = await groupUserRepo.GetAllGroupUsersByProjectID(projectID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }



        [HttpGet("GetAllGrpUserGUAGsByGrpID")]
        public async Task<ActionResult> GetAllGrpUserGUAGsByGrpID([FromQuery]string grpID)
        {
            try
            {
                return Ok(await groupUserRepo.GetAllGrpUserGUAGsByGrpID(grpID));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }




        [HttpGet("GetAllGrpUserSpecialUsersByGrpID")]
        public async Task<ActionResult> GetAllGrpUserSpecialUsersByGrpID([FromQuery]string grpID)
        {
            try
            {
                return Ok(await groupUserRepo.GetAllGrpUserSpecialUsersByGrpID(grpID));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }





        [HttpGet("{id}")]
        public async Task<ActionResult<AdmGroupUser>> getGrpUserById(string id)
        {
            try
            {
                var result = await groupUserRepo.GetGroupUserById(id);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }




        //20200616
        [HttpGet("GetListOU")]
        public JArray GetListOU([FromQuery] string ou)
        {
            var result = groupUserRepo.GetListOU(ou);
            return result;
        }



        [HttpPut("UpdateGroupUser")]
        public async Task<ActionResult<AdmGroupUser>> UpdateGroupUser([FromQuery]string grpUserID, [FromBody]AdmGroupUser gUSer)
        {
            try
            {
                if (grpUserID != gUSer.GroupUserID)
                    return BadRequest("Group User ID mismatch");

                var gUserToUpdate = await groupUserRepo.GetGroupUserById(grpUserID);

                if (gUserToUpdate == null)
                    return NotFound($"Group User with Id = {grpUserID} not found");

                return await groupUserRepo.Update(gUSer);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error updating data");
            }
        }



        [HttpGet("GetDetailGroupUserBygrpID")]
        public async Task<ActionResult<List<GroupUserGUAGDetail>>> GetDetailGroupUserBygrpID([FromQuery] string grpID)
        {
            try
            {
                var result = await groupUserRepo.GetDetailGroupUserBygrpID(grpID);

                if (result == null) return NotFound();

                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieving data from the database");
            }
        }





        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<AdmGroupUser>> CreateGroupUser(AdmGroupUser gUser)
        {
            try
            {
                if (gUser == null)
                    return BadRequest();

                var createGroupUser = await groupUserRepo.CreateGroupUser(gUser);

                return CreatedAtAction(nameof(getGrpUserById),
                    new { id = createGroupUser.GroupUserID }, createGroupUser);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error creating new Group User record");
            }
        }



        [HttpDelete("DeleteGroupUser")]
        public async Task<ActionResult<AdmGroupUser>> DeleteGroupUser([FromQuery]string gUserID)
        {
            try
            {
                var gUserToDelete = await groupUserRepo.GetGroupUserById(gUserID);

                if (gUserToDelete == null)
                {
                    return NotFound($"Group User with Id = {gUserID} not found");
                }

                await groupUserRepo.DeleteGroupUser(gUserID);
                return gUserToDelete;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error deleting data");
            }
        }
    }
}