﻿// Encrypt: Encode plain text into Base64 string
function base64Encode(plainText) {
    if (plainText == null || plainText.length <= 0) return null;
    return window.btoa(plainText);
}
// Encrypt: Decode Base64 string into plain text
function base64Decode(encodedText) {
    if (encodedText == null || encodedText.length <= 0) return null;
    return window.atob(encodedText);
}
// Session: Set session item value
function setSession(key, value) {
    // Encode plain text into Base64 string before puting into session item
    window.sessionStorage.setItem(key, base64Encode(value));
}
// Session: Get session item value
function getSession(key) {
    // Decode Base64 string into plain text before return value
    return base64Decode(window.sessionStorage.getItem(key));
}
// Session: Remove session item
function removeSession(key) {
    window.sessionStorage.removeItem(key);
}
// Language: 
function changeLanguage(langCode) {
    currentLang = langCode;
    setSession('8512ae7d57b1396273f76fe6ed341a23', langCode);
    return langCode;
    
}
// Get token from API host
function GetToken(user) {
    return $.ajax({
        type: "POST",
        url: apiHost + 'token/gettoken',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(user)
    }).done(function (responseText) {
        // "94a08da1fecbb6e8b46990538c7b50b2" - is a session item which save token value
        setSession('94a08da1fecbb6e8b46990538c7b50b2', responseText);
        return 'OK';
    }).fail(function (responseText) {
            swal('Error when get token', responseText, 'error');
            return responseText;
        });

}

function serverLog(user, funct, message, type) {
    let log = {};
    log.username = user;
    log.function = funct;
    log.message = message;
    log.type = type;
    log.clientIP = "Test.Client.IP";

    $.ajax({
        type: "POST",
        url: '/Log',
        contentType: 'application/json',
        data: JSON.stringify(log)
    }).done(function (responseText) {
        
        return 'OK';
    }).fail(function (responseText) {
       
        return responseText;
    });

}
 // Convert plain text into Encoded string (SITV_LIB)
function EncryptText(plainText) {
    var data = {};
    data.pass = plainText;
    let result = null;
    $.ajax({
        type: "POST",
        url: apiHost + 'admSpecialUser/GetEnscriptPassword',
        async: false,
        contentType: 'application/json',
        headers: {
            'Authorization': 'Bearer ' + getSession('94a08da1fecbb6e8b46990538c7b50b2')
        },
        data: JSON.stringify(data)
    }).done(function (responseText) {
        result = responseText.pass;
    }).fail(function (responseText) {
        result = responseText;
    });
    return result;

}