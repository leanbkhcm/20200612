﻿var master = angular.module('masterApp', []);
var token = null;
var currentLang = 'vi';
master.controller('masterCtrl', function ($scope, $http, $interval) {
    //language: 8512ae7d57b1396273f76fe6ed341a23
    currentLang = getSession('8512ae7d57b1396273f76fe6ed341a23');
    if (currentLang == null || currentLang == 'undefined') {
        currentLang = 'vi';
        setSession('8512ae7d57b1396273f76fe6ed341a23', 'vi')
    }
    $scope.currentLang = currentLang;
    $scope.user = getSession('ee11cbb19052e40b07aac0ca060c23ee');
    if ($scope.user == null) {
        window.location.href = loginScreen;
    }
    try {
        $scope.user = JSON.parse($scope.user);

        //Gettoken
        $scope.token = getSession('94a08da1fecbb6e8b46990538c7b50b2');
        token = $scope.token;
        // Check if token is expired
        if ($scope.token != null && $scope.token != 'undefined') {
            payload = $scope.token.split('.')[1];
            payload = JSON.parse(base64Decode(payload));

            if ((payload.exp * 1000) < (new Date().getTime())) {
                GetToken($scope.user);
                $scope.token = getSession('94a08da1fecbb6e8b46990538c7b50b2');
                token = $scope.token;
            }

        }

        $http.defaults.headers.common['Authorization'] = 'Bearer ' + $scope.token;
    }
    catch (err) {
        //alert(err);
        //window.location.href = '/Login';
    }

    // Get language
    $http.get("/lang/" + currentLang + '.master.json')
        .then(function (response) { $scope.master = response.data; });

    //Set timer to tracking language changes
    $interval(function () {
        if (currentLang != $scope.currentLang) {
            $scope.currentLang = currentLang;
            $http.get("/lang/" + currentLang + '.master.json')
                .then(function (response) { $scope.master = response.data; });
        }
    }, 1000);


});