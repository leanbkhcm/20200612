﻿var root = angular.module('rootApp', ['masterApp', 'commandApp']);
    var app = angular.module('commandApp', ['ngSanitize', 'ui.select', 'ui.bootstrap.contextMenu']);
    app.controller('commandCtrll', function ($scope, $http, $interval) {
        $scope.user = getSession('ee11cbb19052e40b07aac0ca060c23ee');
        $scope.user = JSON.parse($scope.user);
        $scope.commandIndex = 1;

        //Set timer to tracking language changes
        $http.get("/lang/" + currentLang + '.commands.json')
            .then(function (response) {
                $scope.site = response.data;
                $scope.menuInit();
            });

        $interval(function () {
            if (currentLang != $scope.currentLang) {
                $scope.currentLang = currentLang;
                $http.get("/lang/" + currentLang + '.commands.json')
                    .then(function (response) {
                        $scope.site = response.data;
                        $scope.menuInit();
                    });

            }
        }, 1000);

        // Get projects list
        $http.get(apiHost + 'admproject')
            .then(function (response) {
                $scope.projects = response.data;
                // If has parameter: project
                if (projectId != null) {
                    let index = $scope.projects.findIndex(project => project.projectID === projectId);
                    if ($scope.projects[index] != null) {
                        $scope.LoadFunctions($scope.projects[index]);
                    }

                }
                //.If has parameter: project
                //console.log($scope.projects);
            });

        // Load Functions
        $scope.LoadFunctions = function (project) {
            $http.get(apiHost + 'admfunction/GetFunctionsByProjectID?id=' + project.projectID)
                .then(function (response) {
                    $scope.selectedProject = project;
                    $scope.functions = response.data;
                    $scope.selectedFunction = null;
                    $scope.commands = null;
                    // If has parameter: function
                    if (functionId != null && functionId != '') {
                        let index = $scope.functions.findIndex(funct => funct.functionID === functionId);
                        if ($scope.functions[index] != null) {
                            $scope.LoadCommands($scope.functions[index]);
                        }

                    }
                    //.If has parameter: function

                });
        }
        // Load Commands
        $scope.LoadCommands = function (funct) {
            $http.get(apiHost + 'admcommand/GetCommandsByFuncID?id=' + funct.functionID)
                .then(function (response) {
                    $scope.selectedFunction = funct;
                    $scope.commands = response.data;

                });
        }
        //$('#tableFunction').dataTable();
        // New function function
        $scope.NewCommand = function () {
            $('#modalCommand').modal('show');
            $scope.selectedCommand = null;
            $scope.commandID = null;
            $scope.commandCode = null;
            $scope.commandName = null;
            $scope.commandIdx = $scope.commandIndex;
        }
        // Edit function function
        $scope.EditCommand = function () {
            if ($scope.selectedCommand == null) {
                swal($scope.site.dl_warning, $scope.site.dg_nofunction, "warning");
            }
            else {
                $('#modalCommand').modal('show');
            }
        }
        // Select Command
        $scope.SelectCommand = function (command) {
            $scope.selectedCommand = command;

            $scope.commandID = command.commandID;
            $scope.commandCode = command.commandCode;
            $scope.commandName = command.commandName;
            $scope.commandIdx = command.idx;
        }

        // Delete function function
        $scope.DeleteCommand = function () {
            if ($scope.selectedCommand == null) {
                swal($scope.site.dl_warning, $scope.site.dg_nofunction, "warning");
            }
            else {
                swal({
                    title: $scope.site.dl_confirm,
                    text: $scope.site.dl_notice,
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55", confirmButtonText: $scope.site.btn_ok,
                    cancelButtonText: $scope.site.btncancel,
                    closeOnConfirm: true,
                    closeOnCancel: true
                },
                    function (isConfirm) {
                        if (isConfirm) {
                            $http.delete(apiHost + 'admcommand/DeleteCommand?cmdID=' + $scope.selectedCommand.commandID, null, 'application/json').then(function (response) {

                                // This function handles success
                                swal($scope.site.dg_success, $scope.site.dl_deletesuccess, "success");
                                let index = $scope.commands.findIndex(cmd => cmd.commandID === $scope.selectedCommand.commandID);
                                $scope.commands.splice(index, 1);
                                $scope.selectedCommand = null;
                                // alert(response.data);
                            }, function (response) {
                                // this function handles error
                                swal("Error!", response.data, "error");
                            });

                            //------------------

                        } else {
                            //swal("Cancelled", "Cancelled!", "error");
                        }
                    });
            }
        }
        //Save changes
        $scope.SaveChanges = function () {
            // If create project
            if ($scope.selectedCommand == null) {
                $scope.command = {};
                $scope.command.commandID = $scope.commandID;
                $scope.command.commandCode = $scope.commandCode;
                $scope.command.commandName = $scope.commandName;
                $scope.command.functionID = $scope.selectedFunction.functionID;
                $scope.command.idx = $scope.commandIdx;
                $scope.command.userCreate = $scope.user.userID;
                $scope.command.dateCreate = new Date();

                $http.post(apiHost + 'admcommand/', JSON.stringify($scope.command), 'application/json').then(function (response) {
                    // This function handles success
                    //console.log(response);
                    // if create successfully
                    //functDescription
                    $scope.command = response.data;
                    $scope.commands.push($scope.command);
                    $scope.command = null;
                    $('#modalCommand').modal('hide');
                    $scope.commandIndex += 1;
                    swal($scope.site.dg_success, $scope.site.dg_savesuccess, "success");
                    // alert(response.data);
                }, function (response) {
                    // this function handles error
                    if (response.status == 500) {
                        swal("Error", response.data, "error");
                    }
                    else {
                        swal("Error: " + response.data.title, response.data.errors.FunctionName[0], "error");
                    }
                    // console.log(response );
                });

                //------------------
            }
            // If update project
            else {
                $scope.command = $scope.selectedCommand;
                // $scope.project.projectID = $scope.projectCode;
                $scope.command.commandCode = $scope.commandCode;
                $scope.command.commandName = $scope.commandName;
                $scope.command.idx = $scope.commandIdx;
                $scope.command.functionID = $scope.selectedFunction.functionID;
                $scope.command.userUpdate = $scope.user.userID;
                $scope.command.dateUpdate = new Date();

                $http.put(apiHost + 'admcommand/UpdateCommand?cmdID=' + $scope.command.commandID, JSON.stringify($scope.command), 'application/json').then(function (response) {
                    // This function handles success
                    //console.log(response);
                    // if update successfully
                    let index = $scope.commands.findIndex(cmd => cmd.commandID === $scope.commands.commandID);
                    $scope.commands[index] = response.data;
                    $scope.command = null;
                    $('#modalCommand').modal('hide');
                    swal($scope.site.dg_success, $scope.site.dg_savesuccess, "success");
                    // alert(response.data);
                }, function (response) {
                    // this function handles error
                    if (response.status != 400) {
                        swal("Error", response.data, "error");
                    }
                    else {
                        swal("Error: " + response.data.title, response.data.errors.FunctionName[0], "error");
                    }
                    // console.log(response );
                });

                //------------------

            }
        }
        
        $scope.menuInit = function () {
            // Menu context
            $scope.commandMenu = [
                // NEW IMPLEMENTATION
                {
                    text: $scope.site.btn_new,
                    click: function ($itemScope, $event, modelValue, text, $li) {
                        $scope.NewCommand();
                        console.log($itemScope.command);

                    }
                },
                {
                    text: $scope.site.btn_edit,
                    click: function ($itemScope, $event, modelValue, text, $li) {
                        $scope.SelectCommand($itemScope.command);
                        $scope.EditCommand();
                    }
                },
                {
                    text: $scope.site.btn_delete,
                    click: function ($itemScope, $event, modelValue, text, $li) {
                        $scope.SelectCommand($itemScope.command);
                        $scope.DeleteCommand();
                    }
                }

            ];
            //Menu context
        }

    });

    app.filter('propsFilter', function () {
        return function (items, props) {
            var out = [];

            if (angular.isArray(items)) {
                var keys = Object.keys(props);

                items.forEach(function (item) {
                    var itemMatches = false;

                    for (var i = 0; i < keys.length; i++) {
                        var prop = keys[i];
                        var text = props[prop].toLowerCase();
                        if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
                            itemMatches = true;
                            break;
                        }
                    }

                    if (itemMatches) {
                        out.push(item);
                    }
                });
            } else {
                // Let the output be the input untouched
                out = items;
            }

            return out;
        };
    });