﻿// Address of API host
//var apiHost = 'https://appncc-uat.sitv.com.vn:8083/api/';//localhost:53206
var apiHost = 'http://localhost:53206/api/';
// First screen which end user see first when logged in
var firstScreen = '/Project';
// Login Screen
var loginScreen = '/Login';